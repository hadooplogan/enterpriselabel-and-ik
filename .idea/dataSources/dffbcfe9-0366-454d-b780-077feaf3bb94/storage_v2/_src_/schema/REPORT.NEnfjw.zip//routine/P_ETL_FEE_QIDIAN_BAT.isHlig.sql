CREATE PROCEDURE P_ETL_FEE_QIDIAN_BAT (V_QIDIAN_BEGIN VARCHAR2,V_QIIDAN_END VARCHAR2) AS
 V_DATE VARCHAR2(8);
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_QIDIAN_BAT
--PURPOSE: 3.0平台订单去重计费:批处理
--CREATOR： 夏培娟
--DATE:    2017-09-27
-------------------------------------------------------------
 PRO_LOG('P_ETL_FEE_QIDIAN_BAT','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||',订单的计费标志开始');
  V_DATE:=V_QIDIAN_BEGIN;
  
  /**UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=1
  WHERE SUCCESS_FLAG=1
    AND ORDER_DATE BETWEEN '20170901' AND '20170924'
    AND CUSTOMERID=V_CUSTOMER_3;**/
  
  WHILE V_DATE<=V_QIIDAN_END LOOP
  BEGIN
  
  --企典通用版，只有id和name，一般不计费
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE FUNCTIONCODE ='enterpriseListBasic' --企典通用版
    AND ORDER_DATE =v_date;
  COMMIT;
  
  --关联关系3.1以下功能不计费--
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE functioncode in ('order_status','result','status') --单个订单状态查询/异步请求订单结果/异步请求订单状态
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------京东金融此账户不计费 10002234:C8034C6CD9CCAFDF--------------
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE UUID ='C8034C6CD9CCAFDF' --第一个是暂不计费('专线用户虚拟ukey116'从2017-01-20开始计费) 第二个是测试账户，不计费
    and customerid='2c9180b75c0b0c2c015c0b2f68100006' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------10002438:C7C6D1E194DA5383,从2017-3-15开始计费,但是作为浦发卡中心，jephy手工处理
  -------10002859:35B2DE1B4DDF43C3,从2017-04-17开始
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE UUID in ('C7C6D1E194DA5383','35B2DE1B4DDF43C3') --不计费 此账户一直不计费
    and customerid='2c9180c25dea8e29015e0386d3351622' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -----------1.1、企业查询、人员查询-------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource','newperson')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID   IN (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION where ID_CUSTOMER_3 <>'2c9180965876381d0158b3bd657a0290') --只是新处理的客户
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,param,PRODUCTCODE
    )
    AND PRODUCTCODE in ('enterprise-datasource','newperson')
    AND FEE_FLAG='1'
    AND CUSTOMERID   IN (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION where ID_CUSTOMER_3 <>'2c9180965876381d0158b3bd657a0290') --只是新处理的客户
    AND ORDER_DATE=V_DATE;
  COMMIT;
  -------------1.2关联关系 默认去重，并重新处理参数------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('relations')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION where ID_CUSTOMER_3 <>'2c9180aa5ab13a58015aff0e82410079') --只是新处理的客户
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param),nvl(functioncode_after,functioncode)
    )
    AND PRODUCTCODE in ('relations')
    AND FEE_FLAG='1'
    AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION where ID_CUSTOMER_3 <>'2c9180aa5ab13a58015aff0e82410079') --只是新处理的客户
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_QIDIAN_CUS','按照查询参数去重，处理'||V_DATE||',订单的计费标志结束');

  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_QIDIAN_CUS','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||',订单的计费标志结束');
  
END P_ETL_FEE_QIDIAN_BAT;
/

