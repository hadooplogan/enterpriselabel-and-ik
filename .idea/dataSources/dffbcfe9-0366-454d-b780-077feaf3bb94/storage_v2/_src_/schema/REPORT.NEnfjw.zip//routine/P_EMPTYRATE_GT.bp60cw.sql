CREATE PROCEDURE P_EMPTYRATE_GT AS 
BEGIN
INSERT INTO T_EMPTYRATE_GT_08260901
SELECT T3.CODENAME,
       count(t1.key_type),
       SUM(CASE
             WHEN T2.ENTNAME IS NULL THEN
              1
             ELSE
              0
           END) entNAME_NULL,
       SUM(CASE
             WHEN T4.NAME IS NULL THEN
              1
             ELSE
              0
           END) NAME_NULL,
       sum(CASE
             WHEN  T2.OPFROM >= T2.OPTO OR
                  T2.OPFROM > SYSDATE OR
                  TO_CHAR(T2.OPFROM, 'yyyy-mm-dd') = '1900-01-01' THEN
              1
             ELSE
              0
           END) OPFROM,
           sum(CASE
             WHEN t2.opfrom = t2.opto
    or t2.opfrom > t2.opto

    or t2.opto = to_date('1900-01-01', 'yyyy-mm-dd')
                  
                  THEN
              1
             ELSE
              0
           END) opto
  from (select distinct input_key, key_type
          FROM T_ORDER_DETAIL
         WHERE length(input_key) >= 4
           and product_tpl_code = '1'
           and id_customer = 'CID_00003985'
           and order_date between '20160826' and '20160901') t1
 INNER JOIN (select * from e_gt_baseinfo_0824@newdaas26_dblink   where ENTSTATUS ='1' )T2
  
     ON T1.INPUT_KEY = T2.ENTNAME
    OR T1.INPUT_KEY = T2.REGNO
  left join (SELECT distinct codevalue, CODENAME
               FROM T_DEX_APP_CODELIST
              WHERE CODE_TYPE_VALUE = 'CA01'
                AND SUBSTR(CODEVALUE, 3, 4) = '0000') T3
    ON SUBSTR(T2.REGORG, 1, 2) || '0000' = T3.CODEVALUE
  left join e_gt_person_0824@newdaas26_dblink t4
    on t2.pripid = t4.pripid
 group by T3.CODENAME;
COMMIT;
END P_EMPTYRATE_GT;
/

