CREATE PROCEDURE P_ETL_FEE_CUS (v_customer varchar2,V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_CUS
--PURPOSE: 处理单个客户的计费标志特殊情况
--CREATOR： 夏培娟
--DATE:    2016-10-25
--update:  2017-01-18
-------------------------------------------------------------
  PRO_LOG('P_ETL_FEE_CUS','按照计费去重规则处理是否计费标志，处理'||V_customer||','||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  /**--将已经处理过的计费标志还原成原始状态
  UPDATE DW_ORDER_DETAIL
  SET FEE_FLAG_RS=1,FEE_FLAG_INPUT=1
  WHERE ((PRODUCT_TPL_CODE='3' AND STATE IN ('1'))
        OR PRODUCT_TPL_CODE='9'
        or (PRODUCT_TPL_CODE not in ('3','9') AND STATE IN ('1','-3')) )
    AND IS_FREE<>'7'
    and ID_CUSTOMER=V_CUSTOMER
    AND ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_CUS','按照计费去重规则处理是否计费标志，处理'||V_CUSTOMER||','||V_DATE||'还原当天计费标志结束');
  
  UPDATE DW_ORDER_DETAIL t
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ID_CUSTOMER=v_customer
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --一个月去重
    group by INPUT_KEY,ID_CUSTOMER,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ID_CUSTOMER =v_customer
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
   -----------2.7、长沙银行：集团族谱去重 从2018-02-08开始按月去重-------------------
  UPDATE DW_ORDER_DETAIL T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL
     WHERE PRODUCT_TPL_CODE ='5'--集团族谱去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --长沙银行 集团族谱去重时间：2016/10/13-2017/10/12
       AND ID_CUSTOMER IN ('CID_00000383') --长沙银行
     GROUP BY INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE ='5'--集团族谱去重
    AND FEE_FLAG_INPUT='1'
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER  ='CID_00000383'; --长沙银行
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_CUS','按照计费去重规则处理是否计费标志，处理'||V_customer||','||V_DATE||'的订单，按查询关键字计费结束');
  **/
  
  UPDATE DW_ORDER_DETAIL
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE u_id='8A570FF2830D26B5'
  AND ID_CUSTOMER='CID_00003985'
  AND ORDER_DATE =v_date;
  COMMIT;
  PRO_LOG('P_ETL_FEE_CUS','将阿里云账户“阿里云互联网”置为不计费，处理,'||V_DATE||'的订单，按查询关键字计费结束');
  
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_CUS','按照计费去重规则处理是否计费标志，处理'||V_customer||','||V_BEGIN||'到'||V_END||'范围内的订单结束');
END P_ETL_FEE_CUS;
/

