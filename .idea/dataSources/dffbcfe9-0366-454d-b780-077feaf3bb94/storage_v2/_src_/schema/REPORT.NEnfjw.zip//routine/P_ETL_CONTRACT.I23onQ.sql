CREATE PROCEDURE P_ETL_CONTRACT (IS_RUN_MONTH varchar2,V_CONTRACT varchar2) AS 
BEGIN
  /**-------初始化-----------------------------------------
  --excel名称和t_customer名称不一致
  UPDATE DIM_CONTRACT SET FULL_NAME='远东租赁国际有限公司' WHERE FULL_NAME='远东国际租赁有限公司';
  UPDATE DIM_CONTRACT SET FULL_NAME='上海浦东发展银行' WHERE FULL_NAME='上海浦东发展银行股份有限公司';
  UPDATE DIM_CONTRACT SET FULL_NAME='中国联合网络通信有限公司上海分公司' WHERE FULL_NAME='深圳市佳信征信企业顾问有限公司上海分公司';
  UPDATE DIM_CONTRACT SET FULL_NAME='广发银行' WHERE FULL_NAME='广州发展银行股份有限公司';
  UPDATE DIM_CONTRACT SET FULL_NAME='交通银行股份有限公司' WHERE FULL_NAME='中国交通银行股份有限公司';
 
   UPDATE DIM_CONTRACT SET FULL_NAME='蚂蚁金服' WHERE FULL_NAME='支付宝（中国）网络技术有限公司' AND BRIEF_NAME='蚂蚁金服';
UPDATE DIM_CONTRACT SET FULL_NAME='交通银行股份有限公司信用卡中心' WHERE FULL_NAME='北京国政通科技有限公司';
UPDATE DIM_CONTRACT SET FULL_NAME='北京首创投资担保有限责任公司' WHERE FULL_NAME='北京首创融资担保有限公司';

  COMMIT;
  --补齐id_customer字段
  UPDATE DIM_CONTRACT T
SET ID_CUSTOMER=(SELECT ID FROM GSINFO.T_CUSTOMER@DAAS WHERE FULL_NAME=T.FULL_NAME);
 --补齐合同周期
  UPDATE  DIM_CONTRACT SET CON_TIME=TO_CHAR(TO_DATE(EFFECT_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd')||'-'||TO_CHAR(TO_DATE(LOST_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd')  WHERE EFFECT_TIME LIKE '20%';
  --补齐合同总期次
   UPDATE DIM_CONTRACT
  SET REPORT_CN=CEIL(MONTHS_BETWEEN(trunc(TO_DATE(LOST_TIME,'yyyy-mm-dd'),'month'),trunc(TO_DATE(EFFECT_TIME,'yyyy-mm-dd'),'month')))+1
  WHERE EFFECT_TIME LIKE '20%';
  --补齐账单月份
     UPDATE DIM_CONTRACT SET YYYYMM='201607' WHERE (EFFECT_TIME<'2016-08-01' AND LOST_TIME>='2016-07-01') OR EFFECT_TIME NOT LIKE '20%' OR EFFECT_TIME IS NULL;
--补齐账单期次
UPDATE DIM_CONTRACT SET  REPORT_TIME=CEIL( MONTHS_BETWEEN(TO_DATE('2016-07-01','yyyy-mm-dd'),TO_DATE(EFFECT_TIME,'yyyy-mm-dd')))+1 WHERE EFFECT_TIME LIKE '20%' AND YYYYMM IS NOT NULL;

--更新账单周期
  UPDATE  DIM_CONTRACT 
  SET REPORT_DATE=CASE WHEN EFFECT_TIME>='2016-07-01' THEN TO_CHAR(TO_DATE(EFFECT_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd') ELSE TO_CHAR(TO_DATE('2016-07-01','yyyy-mm-dd'),'yyyy/fmmm/dd') END||'-'||
  CASE WHEN LOST_TIME>='2016-07-31' THEN TO_CHAR(TO_DATE('2016-07-31','yyyy-mm-dd'),'yyyy/fmmm/dd') ELSE TO_CHAR(TO_DATE(LOST_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd') end
  WHERE YYYYMM IS NOT NULL
  and effect_time like '20%';
  
  UPDATE  DIM_CONTRACT 
  SET REPORT_DATE= TO_CHAR(TO_DATE('2016-07-01','yyyy-mm-dd'),'yyyy/fmmm/dd') ||'-'||TO_CHAR(TO_DATE('2016-07-31','yyyy-mm-dd'),'yyyy/fmmm/dd')
  WHERE YYYYMM IS NOT NULL
  and effect_time not like '20%';
  
  
  ----------查询限额表初始化------------------
  UPDATE DIM_CUSTOMER_LIMIT SET FULL_NAME='远东租赁国际有限公司' WHERE FULL_NAME='远东国际租赁有限公司';
  UPDATE DIM_CUSTOMER_LIMIT SET FULL_NAME='上海浦东发展银行' WHERE FULL_NAME='上海浦东发展银行股份有限公司';
  UPDATE DIM_CUSTOMER_LIMIT SET FULL_NAME='广发银行' WHERE FULL_NAME='广州发展银行股份有限公司';
  UPDATE DIM_CUSTOMER_LIMIT SET FULL_NAME='北京首创投资担保有限责任公司' WHERE FULL_NAME='北京首创融资担保有限公司';
  
  UPDATE DIM_CUSTOMER_LIMIT T SET ID_CUSTOMER=(SELECT ID FROM GSINFO.T_CUSTOMER@DAAS WHERE FULL_NAME=T.FULL_NAME);**/
--每月1号处理当月数据，是否执行在存储过程内控制  
if IS_RUN_MONTH='Y' then 
  ---------------------每月1号自动更新,每月一号跑上月的数据-------------------
  DELETE FROM DIM_CONTRACT 
  WHERE YYYYMM=SUBSTR(V_CONTRACT,1,6) 
    AND ((EFFECT_TIME<TO_CHAR(TO_DATE(V_CONTRACT,'yyyy-mm-dd'),'yyyy-mm-dd') OR EFFECT_TIME='/') OR 
        id_customer in ('CID_00000289','CID_00000004'));
    
  COMMIT;
  INSERT INTO DIM_CONTRACT
    (
    ID_CUSTOMER,
    FULL_NAME,
    EFFECT_TIME,
    LOST_TIME,
    FEE_TYPE,
    CON_TIME,
    REPORT_CN,
    REPORT_TIME,
    BRIEF_NAME,
    YYYYMM,
    REPORT_DATE
   )
  SELECT 
    ID_CUSTOMER,
    FULL_NAME,
    EFFECT_TIME,
    LOST_TIME,
    FEE_TYPE,
    CON_TIME,
    REPORT_CN,
    case when EFFECT_TIME like '20%' then CEIL( MONTHS_BETWEEN(to_date(V_CONTRACT,'yyyy-mm-dd'),TO_DATE(EFFECT_TIME,'yyyy-mm-dd')))+1 else null end,
    BRIEF_NAME,
    substr(V_CONTRACT,1,6),
    CASE 
      WHEN EFFECT_TIME NOT LIKE '20%' or EFFECT_TIME is null THEN TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd'),'yyyy/fmmm/dd') ||'-'||TO_CHAR(LAST_DAY(to_date(V_CONTRACT,'yyyy-mm-dd')),'yyyy/fmmm/dd')
      WHEN EFFECT_TIME LIKE '20%' THEN (CASE WHEN EFFECT_TIME>=TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd'),'yyyy-mm-dd') THEN TO_CHAR(TO_DATE(EFFECT_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd') ELSE TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd'),'yyyy/fmmm/dd') END)||'-'||
           (CASE WHEN LOST_TIME>=TO_CHAR(LAST_DAY(to_date(V_CONTRACT,'yyyy-mm-dd')),'yyyy-mm-dd') THEN TO_CHAR(LAST_DAY(to_date(V_CONTRACT,'yyyy-mm-dd')),'yyyy/fmmm/dd') ELSE TO_CHAR(TO_DATE(LOST_TIME,'yyyy-mm-dd'),'yyyy/fmmm/dd') end )
    END 
  FROM
    DIM_CONTRACT 
  WHERE YYYYMM=TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd')-1,'yyyymm')
    AND (LOST_TIME>=TO_CHAR(TO_DATE(V_CONTRACT,'yyyy-mm-dd'),'yyyy-mm-dd') OR LOST_TIME IS NULL OR LOST_TIME='/')
  -----------中关村合同已到期，但是合同备注是：如果到期后有余量可以延期-----------------
  UNION ALL   
  SELECT 
    ID_CUSTOMER,
    FULL_NAME,
    EFFECT_TIME,
    LOST_TIME,
    FEE_TYPE,
    CON_TIME,
    REPORT_CN,
    case when EFFECT_TIME like '20%' then CEIL( MONTHS_BETWEEN(to_date(V_CONTRACT,'yyyy-mm-dd'),TO_DATE(EFFECT_TIME,'yyyy-mm-dd')))+1 else null end,
    BRIEF_NAME,
    substr(V_CONTRACT,1,6),
    TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd'),'yyyy/fmmm/dd')||'-'||TO_CHAR(LAST_DAY(to_date(V_CONTRACT,'yyyy-mm-dd')),'yyyy/fmmm/dd')
  FROM
    DIM_CONTRACT 
  WHERE ID_CUSTOMER='CID_00000289'
    AND YYYYMM=TO_CHAR(TO_DATE(V_CONTRACT,'yyyy-mm-dd')-1,'yyyymm') ;
  /**-----------北京银行合同已到期，但是是包量合同-----------------
  UNION ALL   
  SELECT 
    ID_CUSTOMER,
    FULL_NAME,
    EFFECT_TIME,
    LOST_TIME,
    FEE_TYPE,
    CON_TIME,
    REPORT_CN,
    case when EFFECT_TIME like '20%' then CEIL( MONTHS_BETWEEN(to_date(V_CONTRACT,'yyyy-mm-dd'),TO_DATE(EFFECT_TIME,'yyyy-mm-dd')))+1 else null end,
    BRIEF_NAME,
    substr(V_CONTRACT,1,6),
    TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd'),'yyyy/fmmm/dd')||'-'||TO_CHAR(LAST_DAY(to_date(V_CONTRACT,'yyyy-mm-dd')),'yyyy/fmmm/dd')
  FROM
    DIM_CONTRACT 
  WHERE ID_CUSTOMER='CID_00000004'
    and YYYYMM=TO_CHAR(to_date(V_CONTRACT,'yyyy-mm-dd')-1,'yyyymm') ;
  COMMIT;
  PRO_LOG('P_ETL_CONTRACT','生成'||SUBSTR(V_CONTRACT,1,6)||'的客户账单合同基础信息');**/
ELSE 
  NULL;
END IF;
  
END P_ETL_CONTRACT;
/

