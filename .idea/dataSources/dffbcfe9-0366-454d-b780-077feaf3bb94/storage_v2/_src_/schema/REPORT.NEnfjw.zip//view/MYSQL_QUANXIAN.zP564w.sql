CREATE VIEW MYSQL_QUANXIAN AS
  SELECT T1.ID customer_id,T1.BRIEF_NAME,T1.NAME,T1.STATE cus_state,case when T1.STATE=1 then '人工禁用' when T1.STATE=0 then '正常' end customer_state,
    T2.NAME CONTRACT_NAME,T2.STATE con_state,case when T2.STATE=1 then '已终止'  when T2.STATE=0 then '执行中' else '未开始' end contract_state  ,
    t2.type con_type,case when T2.TYPE=0 then '合同中客户' when T2.TYPE=1 then '待续约客户' when T2.TYPE=2 then '待签约客户' when T2.TYPE=3 then '试用客户' else '停用客户' end contract_type ,
    T2.STOP_REASON,T2.sign_DATE,T2.end_DATE,t2.bill_end_date,
    t3.name saler,
    t4.status product_status,
   t4.product_code ,
   case when t4.product_name ='关联关系-3.1' then '关联洞察' when t4.product_name ='企业名录' then '企典'else t4.product_name end product_name,
    t5.grant_type,case when t5.status='1' then '正常' else '不正常' end status, 
    t5.column_id,t5.column_name,t5.column_type,
SUBSTR(COLUMN_ID,INSTR(COLUMN_ID,'.',1,1)+1,INSTR(COLUMN_ID,'.',1,2)-INSTR(COLUMN_ID,'.',1,1)-1) COLUMNID_module,
SUBSTR(COLUMN_ID,INSTR(COLUMN_ID,'.',1,2)+1,length(COLUMN_ID)-INSTR(COLUMN_ID,'.',1,2)) COLUMNID_code,
    t5.function_code,
    case when t5.function_name='人员任职核验V2' then '人员任职核验（通用版）' when t5.function_name='人员任职核验' then '人员任职核验（专业版）' else t5.function_name end function_name,
    t7.name role_name,t7.state cole_state,t7.id role_id,
    t8.state user_state,t8.u_id,t8.user_name,t8.name user_zh_name,
t8.user_tag
  FROM MYSQL_T_CUSTOMER T1  --客户表
  LEFT JOIN MYSQL_T_CONTRACT T2 ON T1.ID=T2.CUSTOMER_ID --合同表
  left join MYSQL_T_SYS_USER t3 on t2.sale_user_id=t3.id --对应的销售
  LEFT JOIN MYSQL_T_PRODUCT_INSTANCE T4 ON T2.ID=T4.CONTRACT_ID  --合同产品权限表
  left join MYSQL_T_CONTRACT_COL t5 on t4.id=t5.product_instance_id --合同功能、字段权限表
  left join mysql_t_role_col t6 on t4.id=t6.product_instance_id and t5.id=t6.contract_col_id --角色的权限
  left join mysql_t_role t7 on t6.role_id=t7.id --角色名称
left join (SELECT t1.role_id,t1.state,T1.U_ID,T1.USER_NAME,t1.name,T2.USER_ID,dbms_lob.substr(wmsys.wm_concat(T3.NAME),4000) user_tag
FROM MYSQL_T_USER T1
LEFT JOIN MYSQL_T_USER_TAG_RS T2 ON T1.ID=T2.USER_ID
LEFT JOIN MYSQL_T_USER_TAG T3 ON T2.TAG_ID=T3.ID
GROUP BY t1.role_id,t1.state,T1.U_ID,T1.USER_NAME,t1.name,T2.USER_ID) t8 on t7.id=t8.role_id--用户名称
/

