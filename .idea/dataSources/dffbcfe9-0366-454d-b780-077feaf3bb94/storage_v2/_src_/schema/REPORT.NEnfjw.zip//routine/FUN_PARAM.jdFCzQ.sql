CREATE FUNCTION FUN_PARAM (PARAM IN VARCHAR2) RETURN VARCHAR2 AS 
PARAM_RETURN VARCHAR2(2000);
-------------------------------------------
--NAME: FUN_PARAM
--PURPOSE:处理多节点关联关系的顺序问题
--CREATOR： 夏培娟
--DATE:    2017-09-13
-------------------------------------------
BEGIN
--只截取查询对象
PARAM_RETURN:=REPLACE(SUBSTR(PARAM,10,INSTR(PARAM,'],')-11),'"','');

return(PARAM_RETURN);
END FUN_PARAM;
/

