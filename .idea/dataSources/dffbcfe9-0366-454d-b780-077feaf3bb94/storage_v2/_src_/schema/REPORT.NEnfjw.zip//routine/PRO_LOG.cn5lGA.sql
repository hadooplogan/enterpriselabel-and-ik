CREATE PROCEDURE PRO_LOG(LOGNAME VARCHAR2, LOGCONT VARCHAR2)
AS
  VBEGINTIME DATE;
  VPK_ETL_LOG VARCHAR2(20);
  VDATE VARCHAR2(20);
  VNEXTVAL VARCHAR2(20);
-------------------------------------------------------------
--NAME:    PRO_LOG
--PURPOSE: 生成日志，供数据处理的存储过程调用
--CREATOR： XPJ
--DATE:    2016-06-23
-------------------------------------------------------------
BEGIN
  VBEGINTIME := SYSDATE;
  
  BEGIN
  SELECT TRIM(TO_CHAR(SEQ_BI.nextval,'000000')) INTO Vnextval
  FROM DUAL;
  END;
  
  VPK_ETL_LOG := TO_CHAR (VBEGINTIME, 'yyyymmddhh24miss')||Vnextval;
  VDATE := TO_CHAR (VBEGINTIME, 'yyyy-mm-dd hh24:mi:ss');
  INSERT INTO Z_ETL_LOG ( PK_ETL_LOG, LOGNAME, LOGDATE, LOG ) VALUES ( VPK_ETL_LOG, LOGNAME, VDATE, LOGCONT );
COMMIT;
END PRO_LOG;
/

