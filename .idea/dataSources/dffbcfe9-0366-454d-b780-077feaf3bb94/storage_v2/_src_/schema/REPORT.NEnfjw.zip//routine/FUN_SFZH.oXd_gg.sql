CREATE function fun_sfzh(cc_sfzh in varchar2) return varchar2 is
  zq_shzh varchar2(18);
  c1 number;
  c2 number;
  c3 number;
  c4 number;
  c5 number;
  c6 number;
  c7 number;
  c8 number;
  c9 number;
  c10 number;
  c11 number;
  c12 number;
  c13 number;
  c14 number;
  c15 number;
  c16 number;
  c17 number;
  vs  number;
  vm  number;
  
begin
  if length(cc_sfzh)=18 and regexp_like(substr(cc_sfzh,1,17),'^[[:digit:]]+$') then --18位 ，且前17位为纯数字
    c1:=to_number(substr(cc_sfzh,1,1));
    c2:=to_number(substr(cc_sfzh,2,1));
    c3:=to_number(substr(cc_sfzh,3,1));
    c4:=to_number(substr(cc_sfzh,4,1));
    c5:=to_number(substr(cc_sfzh,5,1));
    c6:=to_number(substr(cc_sfzh,6,1));
    c7:=to_number(substr(cc_sfzh,7,1));
    c8:=to_number(substr(cc_sfzh,8,1));
    c9:=to_number(substr(cc_sfzh,9,1));
    c10:=to_number(substr(cc_sfzh,10,1));
    c11:=to_number(substr(cc_sfzh,11,1));
    c12:=to_number(substr(cc_sfzh,12,1));
    c13:=to_number(substr(cc_sfzh,13,1));
    c14:=to_number(substr(cc_sfzh,14,1));
    c15:=to_number(substr(cc_sfzh,15,1));
    c16:=to_number(substr(cc_sfzh,16,1));
    c17:=to_number(substr(cc_sfzh,17,1));
    
    
    vs:=(c1*7)+(c2*9)+(c3*10)+(c4*5)+(c5*8)+(c6*4)+(c7*2)+(c8*1)+(c9*6)+(c10*3)+(c11*7)+
        (c12*9)+(c13*10)+(c14*5)+(c15*8)+(c16*4)+(c17*2);
    
    vm:=mod(vs,11);
    
    if vm=0 then zq_shzh:=substr(cc_sfzh,1,17)||'1'; end if;
    if vm=1 then zq_shzh:=substr(cc_sfzh,1,17)||'0'; end if;
    if vm=2 then zq_shzh:=substr(cc_sfzh,1,17)||'X'; end if;
    if vm=3 then zq_shzh:=substr(cc_sfzh,1,17)||'9'; end if;
    if vm=4 then zq_shzh:=substr(cc_sfzh,1,17)||'8'; end if;
    if vm=5 then zq_shzh:=substr(cc_sfzh,1,17)||'7'; end if;
    if vm=6 then zq_shzh:=substr(cc_sfzh,1,17)||'6'; end if;
    if vm=7 then zq_shzh:=substr(cc_sfzh,1,17)||'5'; end if;
    if vm=8 then zq_shzh:=substr(cc_sfzh,1,17)||'4'; end if;
    if vm=9 then zq_shzh:=substr(cc_sfzh,1,17)||'3'; end if;
    if vm=10 then zq_shzh:=substr(cc_sfzh,1,17)||'2'; end if;
  
  else null;
  end if;
 return(zq_shzh);
end fun_sfzh;
/

