CREATE PROCEDURE P_MAYI_0809 AS 
BEGIN
  INSERT INTO T_MAYI_07250805
SELECT  order_no,order_from,key_type,input_key,
to_char(submit_time,'YYYY-MM-DD') submit_time,
to_char(ACCEPT_time,'YYYY-MM-DD') ACCEPT_time,
to_char(FINISH_time,'YYYY-MM-DD') FINISH_time,
RESPONSE_TIME,
 CEIL((FINISH_TIME-SUBMIT_TIME)*24*60*60*1000) RESPONSE_HSTIME
FROM  T_ORDER_DETAIL
WHERE ID_CUSTOMER='CID_00000627' AND  --客户
ORDER_DATE BETWEEN '20160725' AND '20160805'  --订单时间范围
and (STATE<>'1' and state<>'-3') 
and KEY_TYPE IN ('2','3','5','13')--按企业查询
and not 
(KEY_TYPE  ='2' 
and not regexp_like(input_key,'[0-9]') 
and ((length(input_key)=2 or length(input_key)=3 ) and input_key<>'无' and input_key<>'-' and  input_key<>'特批' )
)
and not (
KEY_TYPE  ='2'
AND (REGEXP_LIKE(INPUT_KEY,'\。$')
or REGEXP_LIKE(INPUT_KEY,'\.$')
or REGEXP_LIKE(INPUT_KEY,'\。$')
or REGEXP_LIKE(INPUT_KEY,'\·$')
or REGEXP_LIKE(INPUT_KEY,'\:$')
or REGEXP_LIKE(INPUT_KEY,'[1-9]$')
or REGEXP_LIKE(INPUT_KEY,'[1-9]\)$')
or REGEXP_LIKE(INPUT_KEY,'公$')
)
)

and not (KEY_TYPE  ='13' and (not regexp_like(input_key,'^9([0-9]|[A-Z]){17}$')) 
AND (LENGTH(input_key)=15 OR (LENGTH(input_key)=18 AND (substr(input_key,7,2)='19' OR substr(input_key,7,2)='20'))))
and not (KEY_TYPE  ='3' and regexp_like(input_key,'^(([0-9]|[A-Z]|[a-z]){8}\-([0-9]|[A-Z]|[a-z]){1})$'))
and not (KEY_TYPE  ='3' and REGEXP_LIKE(INPUT_KEY,'\)$'))
and not 
(KEY_TYPE  ='3' and not regexp_like(input_key,'[0-9]')
and ((length(input_key)=2 or length(input_key)=3 ) and input_key<>'无' and input_key<>'-' and  input_key<>'特批' ));
COMMIT;
END P_MAYI_0809;
/

