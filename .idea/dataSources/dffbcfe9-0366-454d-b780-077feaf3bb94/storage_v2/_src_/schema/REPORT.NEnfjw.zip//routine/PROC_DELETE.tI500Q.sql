CREATE PROCEDURE PROC_DELETE AS 
BEGIN
delete from dw_order_3_jpa where to_char(starttime,'yyyy-mm-dd') < '2017-01-01';
COMMIT;
END PROC_DELETE;
/

