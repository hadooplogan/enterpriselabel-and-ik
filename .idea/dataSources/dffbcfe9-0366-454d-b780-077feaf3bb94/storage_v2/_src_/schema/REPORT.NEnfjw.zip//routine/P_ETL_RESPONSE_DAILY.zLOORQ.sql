CREATE PROCEDURE P_ETL_RESPONSE_DAILY (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    DM_RESPONSE_DAILY
--PURPOSE: 响应时间汇总表
--CREATOR： 夏培娟
--DATE:    2016-12-30
-------------------------------------------------------------
BEGIN
PRO_LOG('P_ETL_RESPONSE_DAILY','抽取'||V_BEGIN||'到'||V_END||'响应时间汇总数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  --删除当天原有数据
  DELETE FROM DM_RESPONSE_DAILY WHERE   ORDER_DATE=V_DATE;
  INSERT INTO DM_RESPONSE_DAILY
    (ORDER_DATE,
    ID_CUSTOMER,
    BATCH_NO,
    STATE,
    KEY_TYPE,
    U_ID,
    UKEY_NO,
    user_name,
    ORDERNUM,
    "500ms以内",
    "1秒以内",
    "2秒以内",
    "2秒以上",
    avg_time
    )
  SELECT ORDER_DATE,
    id_customer,
    case when BATCH_NO is null then null else '001' end batch_no,
    STATE,
    KEY_TYPE,
    U_ID,
    UKEY_NO,
    user_name,
    COUNT(1) ORDERNUM,
    sum(CASE WHEN RESPONSE_TIME_MS<=500 THEN 1 ELSE 0 END) "500ms以内",
    sum(CASE WHEN RESPONSE_TIME_MS<=1000 THEN 1 ELSE 0 END) "1秒以内",
    sum(CASE WHEN RESPONSE_TIME_MS<=2000 THEN 1 ELSE 0 END) "2秒以内",
    sum(CASE WHEN RESPONSE_TIME_ms>2000 OR RESPONSE_TIME IS NULL  THEN 1 ELSE 0 END) "2秒以上",
    avg(RESPONSE_TIME_MS)
  FROM dw_ORDER_DETAIL
  WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')
  AND ORDER_DATE =v_date
  group by ORDER_DATE,
    id_customer,
    case when BATCH_NO is null then null else '001' end ,
    STATE,
    KEY_TYPE,
    U_ID,
    UKEY_NO,
    user_name;
  COMMIT;
  
  --统计订单提交数>50笔/秒的时间分布
   --删除当天原有数据
  DELETE FROM DM_RESPONSE_50_S WHERE   ORDER_DATE=V_DATE;
  INSERT INTO DM_RESPONSE_50_S
    (ORDER_DATE, 
     SUBMIT_TIME, 
     CN, 
     CN_NOT_BATCH
    )
  SELECT *
  FROM
    (SELECT ORDER_DATE,
      TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd hh24:mi:ss') SUBMIT_TIME,
      COUNT(*) cn,
      SUM(CASE  WHEN BATCH_NO IS NULL  THEN 1  ELSE 0 END) CN_NOT_BATCH
    FROM DW_ORDER_DETAIL
    WHERE PRODUCT_TPL_CODE IN ('1','10')
    AND ORDER_DATE =V_DATE
    GROUP BY ORDER_DATE,TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd hh24:mi:ss')
    )
  WHERE CN_NOT_BATCH>50;
  COMMIT;
  
  PRO_LOG('P_ETL_RESPONSE_DAILY','抽取'||V_DATE||'响应时间汇总数据结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;

  COMMIT;
  PRO_LOG('P_ETL_RESPONSE_DAILY','抽取'||V_BEGIN||'到'||V_END||'响应时间汇总数据结束');

END P_ETL_RESPONSE_DAILY;
/

