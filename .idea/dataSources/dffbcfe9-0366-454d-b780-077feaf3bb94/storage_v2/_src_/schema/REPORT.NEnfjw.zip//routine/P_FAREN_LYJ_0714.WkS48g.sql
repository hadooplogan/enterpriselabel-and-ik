CREATE PROCEDURE P_FAREN_LYJ_0714 AS 
BEGIN
INSERT INTO FAREN_LYJ_0714
select case ent.entstatus
when '1' then '在营'
when '2' then '吊销'
when '3' then '注销'
when '4' then '迁出'
when '8' then '停业'
when '9' then '其他' 
else ent.entstatus END,count(distinct ent.pripid)   
from ENTERPRISEBASEINFO_0714@NEWDAAS26_DBLINK ent
group by ent.entstatus;
COMMIT;
END P_FAREN_LYJ_0714;
/

