CREATE PROCEDURE P_ETL_FEE_2015 (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  CNT NUMBER;
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_2015
--PURPOSE: 处理2015年的计费标志
--CREATOR： 夏培娟
--DATE:    2017-12-27
-------------------------------------------------------------
  PRO_LOG('P_ETL_FEE_2015','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  ---删除vip客户的监控订单,前期用中数智汇，后边用虚拟公司“中数智汇业务监控”，并且不用区分客户----
  DELETE FROM DW_ORDER_DETAIL_2015
  WHERE INPUT_KEY='北京中数智汇科技股份有限公司'
    AND PRODUCT_TPL_CODE='1' --基本查询订单
    and ID_CUSTOMER IN ('CID_00000009','CID_00000443','CID_00000963','CID_00001363','CID_00003985','CID_00007683')
    AND ORDER_DATE=V_DATE;
  COMMIT; 
  
  DELETE FROM DW_ORDER_DETAIL_2015
  WHERE INPUT_KEY='中数智汇业务监控'
    AND PRODUCT_TPL_CODE='1' --基本查询订单
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------首先处理state=-3时候的订单----------
  UPDATE DW_ORDER_DETAIL_2015
  SET RS_KEY=NULL,STATE_ORI='-3',STATE='-1',FEE_FLAG_INPUT=0,FEE_FLAG_RS=0 --将state置为-1，方便后续查询失败订单，同时STATE_ORI保留原始state状态信息
  WHERE (RS_KEY IS NULL OR RS_KEY=',') --失败订单，因为查询结果为空
    AND STATE='-3' --已删除订单
    AND PRODUCT_TPL_CODE IN ('1','10','11','12') --基本查询订单
    AND ORDER_DATE=V_DATE;
  COMMIT; 
  ------处理is_free=7的不计费账户订单-----
  UPDATE DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE IS_FREE='7' --不计费
    AND ORDER_DATE=V_DATE;
  COMMIT;
  -------10002438,从2017-3-15开始计费,但是作为浦发卡中心，jephy手工处理
  -------10002859,从2017-04-17开始
  UPDATE DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no in ('10002438','10002859') --不计费 此账户一直不计费
    and id_customer='CID_00000040' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  -------江苏农信此账户不计费--------------
  UPDATE DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no='专线用户虚拟ukey26' --不计费 接口测试账号，一直不计费
    and id_customer='CID_00000583' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  -------京东金融此账户不计费--------------
  UPDATE DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no in ('10002234') --第一个是暂不计费('专线用户虚拟ukey116'从2017-01-20开始计费) 第二个是测试账户，不计费
    and id_customer='CID_00007683' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  ---------------东亚银行零售界面用户除去：00002094-00002113、10001071、10001072,按查得量不去重计费---- 
  update DW_ORDER_DETAIL_2015
  set FEE_FLAG_RS=0,fee_flag_input=0
  where ( ukey_no between '00002094' and '00002113' or ukey_no in ('10001071','10001072') )
    and ID_CUSTOMER ='CID_00000503' --东亚银行零售
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --------------南京银行10002513关联关系和集团族谱各可试用10条------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE  product_tpl_code in ('4','5','6')
    and ukey_no ='10002513'
    and ID_CUSTOMER ='CID_00000036' --南京银行
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --------------联源智信10001017试用100条------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no ='10001017'
    and ID_CUSTOMER ='CID_00003084' --联源智信
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --------------考拉征信，10002336 测试账户，组代信息查询 不计费------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE (ukey_no ='10002336' or  order_type='00001')
    and ID_CUSTOMER ='CID_00011683' --考拉征信
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --------------光大银行、亚信数据、杭州银行、泛华集团、人人融资、腾讯、吉贝克 界面账号不计费------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE is_free in ('1','2','6','8')
    AND ID_CUSTOMER IN ('CID_00000643','CID_00013183','CID_00006883','CID_00008083','CID_00014083',
      'CID_00000963','CID_00000883') --光大银行、亚信数据、杭州银行、泛华集团、人人融资、腾讯、吉贝克
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ---------上海银行的界面用户 目前22个界面用户  只有一个10001794收费 其余21个界面用户都是试用账户-----
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE is_free in ('1','2','6','8')
    AND UKEY_NO<>'10001794'
    AND ID_CUSTOMER = 'CID_00001483' --上海银行股份有限公司
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ------------东方金诚，10001395、10002851不计费---------------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no in ('10001395','10002851')--不计费
    and ID_CUSTOMER ='CID_00005983'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ------------卫诚征信，界面账号10002806不计费---------------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no ='10002806'
    and ID_CUSTOMER ='CID_00015683'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ------------江苏银行 CID_00000027,专线用户虚拟ukey179,测试账号不计费，1000条用量
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no ='专线用户虚拟ukey179'
    and ID_CUSTOMER ='CID_00000027'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -----------工商银行CID_00000009，测试账户10002977不计费----------
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ukey_no ='10002977'
    and ID_CUSTOMER ='CID_00000009'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ---------交通银行 CID_00000059，基本查询只以下用户计费：专线用户虚拟ukey140、00001699、00001703、00001709、00001731、00001748、00002406
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE UKEY_NO not IN ('专线用户虚拟ukey140','00001699','00001703','00001709','00001731','00001748','00002406')
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')    --基本查询
    AND ID_CUSTOMER ='CID_00000059'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ------- 中国出口信用保险新开通一个测试界面账号10003082，此账号不计费-----
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE UKEY_NO='10003082'
   AND ID_CUSTOMER='CID_00000077'
   AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------   亚联数据3.0开始计费，仅3.0平台计费，从8月4日开始计费，之前数据清零。-----
  update DW_ORDER_DETAIL_2015
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE ID_CUSTOMER='CID_00016483'
   AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------------处理FEE_FLAG_INPUT 按查询关键字去重---------------------------------
  -----------2.1、一般客户的去重规则：当月、按客户去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 t
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ID_CUSTOMER NOT IN ('CID_00000051','CID_00001223','CID_00000055','CID_00000032',
         'CID_00000503','CID_00000280','CID_00000067','CID_00003985')--前6个不去重  广发 台州 快钱 阿里不去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --一个月去重
    group by INPUT_KEY,ID_CUSTOMER,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ID_CUSTOMER NOT IN ('CID_00000051','CID_00001223','CID_00000055','CID_00000032',
         'CID_00000503','CID_00000280','CID_00000067','CID_00003985')--前6个不去重  广发 台州 快钱 阿里不去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，按查询关键字，处理一般客户的计费标志');
  -----------2.2、广发银行：30天、按客户去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')-29,'yyyymmdd')  AND V_DATE --30天去重
       AND ID_CUSTOMER='CID_00000280' --- 广发银行：30天、按客户去重
     group by INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER='CID_00000280'; --- 广发银行：30天、按客户去重
  COMMIT;
  --PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，按查询关键字，处理30天的计费标志');
  
  -----------2.3、快钱：6个月、按客户去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ID_CUSTOMER='CID_00002283' --- 快钱：6个月、按客户去重
       AND ORDER_DATE BETWEEN '20170401' AND V_DATE --30天去重
    group by INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    and ID_CUSTOMER='CID_00002283' --- 快钱：6个月、按客户去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，按查询关键字，处理6个月的计费标志');
  
  -----------2.4、台州银行：3个月、按客户去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ID_CUSTOMER='CID_00000327' --- 快钱：6个月、按客户去重
       AND ORDER_DATE BETWEEN '20171001'  AND V_DATE --30天去重
    group by INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    and ID_CUSTOMER='CID_00000327' --- 快钱：6个月、按客户去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，台州银行按查询关键字，处理3个月的计费标志');
  
  -----------2.5、鹏元征信：当月、按order_type去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
       AND ID_CUSTOMER='CID_00000067'
    group by INPUT_KEY,KEY_TYPE2,
       DECODE(SUBSTR(ORDER_TYPE,0,35),'10000000000000010000000000000000100','1','10000000000000010000000000010000100','1','00001','1',--'企业照面'
         '11010000000000010000000000000000100','2','11010000000000010000000000010000100','2',-- '照面股东人员'
         '11010001110000010000000000000000100','3','11010001110000010000000000010000100','3',--'投资任职'
         '00000000001110000000000000010000000','4',--'籍贯'
         '00000000001110000000000000000000000', '5')--'个人标示'
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE
    and ID_CUSTOMER='CID_00000067'; --- 快钱：6个月、按客户去重
  COMMIT;
  --PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，台州银行按查询关键字，处理3个月的计费标志');
  
  -----------2.6、惠信易达：关联关系去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 t
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE IN ('4','5','6')--关联关系去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --一个月去重
       AND ID_CUSTOMER ='CID_00000483' --惠信易达
    group by INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('4','5','6')--关联关系去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER ='CID_00000483'; --惠信易达
  COMMIT;
  
    -----------2.7、长沙银行：集团族谱去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE ='5'--集团族谱去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN '20161013' AND V_DATE --长沙银行 集团族谱去重时间：2016/10/13-2017/10/12
       AND ID_CUSTOMER IN ('CID_00000383') --长沙银行
     GROUP BY INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE ='5'--集团族谱去重
    AND FEE_FLAG_INPUT='1'
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER  ='CID_00000383'; --长沙银行
  COMMIT;
  
  -----------2.8、东亚银行：集团族谱去重-------------------
  UPDATE DW_ORDER_DETAIL_2015 T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_2015
     WHERE PRODUCT_TPL_CODE ='5'--集团族谱去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN '20160101' AND V_DATE --东亚银行（中国）有限公司 集团族谱去重时间：2016/1/1-2017/12/31
       AND ID_CUSTOMER IN ('CID_00004783') --东亚银行
     GROUP BY INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE ='5'--集团族谱去重
    AND FEE_FLAG_INPUT='1'
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER  ='CID_00004783' ;--东亚银行
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_2015','按照计费去重规则处理是否计费标志，处理'||V_DATE||'的订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_2015','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');

END P_ETL_FEE_2015;
/

