CREATE PROCEDURE P_EMPTYRATE_ENT_NEW_ZS AS 
BEGIN
INSERT INTO  T_EMPTYRATE_ENT_09020908_ZS 
SELECT t.S_EXT_NODENUM,
       
       zl,
       m1 AS "企业名称空",
       m2 as "法人为空",
       m3 as "opfrom",
       m4 as "opto"

  FROM (SELECT S_EXT_NODENUM, count(*) as zl
          FROM ENTERPRISEBASEINFOCOLLECT@NEWDAAS26_DBLINK 
         where ENTSTATUS = '1'
         GROUP BY S_EXT_NODENUM) t
  left join (SELECT S_EXT_NODENUM, count(*) as m1
               FROM ENTERPRISEBASEINFOCOLLECT@NEWDAAS26_DBLINK 
              WHERE entname is null
                and ENTSTATUS = '1'
              GROUP BY S_EXT_NODENUM) t1
    on t.s_ext_nodenum = t1.s_ext_nodenum
  left join (SELECT S_EXT_NODENUM, count(*) as m2
               FROM ENTERPRISEBASEINFOCOLLECT@NEWDAAS26_DBLINK 
              WHERE name is null
                and ENTSTATUS = '1'
              GROUP BY S_EXT_NODENUM) t2
    on t.s_ext_nodenum = t2.s_ext_nodenum
    left join (select s_ext_nodenum, count(*) as m3
                from ENTERPRISEBASEINFOCOLLECT@NEWDAAS26_DBLINK 
               where (opfrom is null
                  or opfrom = opto
                  or opfrom > opto
                  or opfrom > sysdate
                  or opfrom = to_date('1900-01-01', 'yyyy-mm-dd'))
                    and ENTSTATUS = '1'
               group by s_ext_nodenum) t2
     on t.s_ext_nodenum = t2.s_ext_nodenum
     
   left join (select s_ext_nodenum ,count(*)as m4
  from   ENTERPRISEBASEINFOCOLLECT@NEWDAAS26_DBLINK  
 where (
     opfrom = opto
    or opfrom > opto
    or opto = to_date('1900-01-01', 'yyyy-mm-dd'))
     and ENTSTATUS = '1'
    group by s_ext_nodenum
    ) t3
     on t.s_ext_nodenum = t3.s_ext_nodenum

 ORDER BY t.S_EXT_NODENUM;
 COMMIT;
END P_EMPTYRATE_ENT_NEW_ZS;
/

