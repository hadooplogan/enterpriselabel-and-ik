CREATE PROCEDURE P_ETL_BI_DAILY (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_BI_DAILY
--PURPOSE: 生成运营分析的日报数据
--CREATOR： 夏培娟
--DATE:    2016-09-07
-------------------------------------------------------------
BEGIN
  PRO_LOG('P_ETL_BI_DAILY','抽取'||V_BEGIN||'到'||V_END||'运营分析的日报数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  ---删除当天已有日报数据
  DELETE FROM T_BI_DAILY WHERE 订单时间=substr(V_DATE,1,4)||'-'||substr(V_DATE,5,2)||'-'||substr(V_DATE,7,2);
  COMMIT;
  --插入当天日报数据
  INSERT INTO T_BI_DAILY
    (订单时间,ID_CUSTOMER,FULL_NAME,BRIEF_NAME,saler,
    查询量,查得量,查得率,计费量,计费率,
    企业查询量,企业查询查得量,企业查得率,企业查询计费量,企业计费率,
    人员查询量,人员查询查得量,人员查得率,人员查询计费量,人员计费率,
    企业名称查询量,企业名称查得量,企业名称查得率,企业名称计费量,企业名称计费率,
    企业注册号查询量,企业注册号查得量,企业注册号查得率,企业注册号计费量,企业注册号计费率,
    组织机构代码查询量,组织机构代码查得量,组织机构代码查得率,组织机构代码计费量,组织机构代码计费率,
    统一社会信用代码查询量,统一社会信用代码查得量,统一社会信用代码查得率,统一社会信用代码计费量,统一社会信用代码计费率,
    人员证件号查询量,人员证件号查得量,人员证件号查得率,人员证件号计费量,人员证件号计费率,
    个人标示查询查询量,个人标示查询查得量,个人标示查询查得率,个人标示查询计费量,个人标示查询计费率,
    按职务查询量,按职务查得量,按职务查得率,按职务计费量,按职务计费率
    )
  -----------------各个客户的情况----------------------------------------------
  SELECT ORDER_DATE 订单时间,
     T1.ID_CUSTOMER,
     T2.FULL_NAME,
     T2.BRIEF_NAME,
     t2.saler,
     CXL 查询量,
     CDL 查得量,
     CASE WHEN CXL=0 THEN NULL ELSE ROUND(CDL/CXL,4) END  查得率,
     JFL 计费量,
     CASE WHEN CDL=0 THEN NULL ELSE ROUND(JFL/CDL,4) END  计费率,
     QY_CXL 企业查询量,
     QY_CDL 企业查询查得量,
     CASE WHEN QY_CXL=0 THEN NULL ELSE ROUND(QY_CDL/QY_CXL,4) END  企业查得率,
     QY_JFL 企业查询计费量,
     CASE WHEN QY_CDL=0 THEN NULL ELSE ROUND(QY_JFL/QY_CDL,4) END  企业计费率,
     RY_CXL 人员查询量,
     RY_CDL 人员查询查得量,
     CASE WHEN RY_CXL=0 THEN NULL ELSE ROUND(RY_CDL/RY_CXL,4) END 人员查得率,
     RY_JFL 人员查询计费量,
     CASE WHEN RY_CDL=0 THEN NULL ELSE ROUND(RY_JFL/RY_CDL,4) END 人员计费率,
     QY_MC_CXL 企业名称查询量, 
     QY_MC_CDL 企业名称查得量, 
     CASE WHEN QY_MC_CXL=0 THEN NULL ELSE ROUND(QY_MC_CDL/QY_MC_CXL,4) END 企业名称查得率,
     QY_MC_JFL 企业名称计费量, 
     CASE WHEN QY_MC_CDL=0 THEN NULL ELSE ROUND(QY_MC_JFL/QY_MC_CDL,4) END 企业名称计费率,
     QY_ZCH_CXL 企业注册号查询量,
     QY_ZCH_CDL 企业注册号查得量,
     CASE WHEN QY_ZCH_CXL=0 THEN NULL ELSE ROUND(QY_ZCH_CDL/QY_ZCH_CXL,4) END 企业注册号查得率,
     QY_ZCH_JFL 企业注册号计费量,
     CASE WHEN QY_ZCH_CDL=0 THEN NULL ELSE ROUND(QY_ZCH_JFL/QY_ZCH_CDL,4) END 企业注册号计费率,
     QY_ZZJGDM_CXL 组织机构代码查询量,
     QY_ZZJGDM_CDL 组织机构代码查得量,
     CASE WHEN QY_ZZJGDM_CXL=0 THEN NULL ELSE ROUND(QY_ZZJGDM_CDL/QY_ZZJGDM_CXL,4) END 组织机构代码查得率,
     QY_ZZJGDM_JFL 组织机构代码计费量,
     CASE WHEN QY_ZZJGDM_CDL=0 THEN NULL ELSE ROUND(QY_ZZJGDM_JFL/QY_ZZJGDM_CDL,4) END 组织机构代码计费率,
     QY_CREDIT_CXL 统一社会信用代码查询量,
     QY_CREDIT_CDL 统一社会信用代码查得量,
     CASE WHEN QY_CREDIT_CXL=0 THEN NULL ELSE ROUND(QY_CREDIT_CDL/QY_CREDIT_CXL,4) END 统一社会信用代码查得率,
     QY_CREDIT_JFL 统一社会信用代码计费量,
     CASE WHEN QY_CREDIT_CDL=0 THEN NULL ELSE ROUND(QY_CREDIT_JFL/QY_CREDIT_CDL,4) END 统一社会信用代码计费率,
     RY_ZJH_CXL 人员证件号查询量,
     RY_ZJH_CDL 人员证件号查得量,
     CASE WHEN RY_ZJH_CXL=0 THEN NULL ELSE ROUND(RY_ZJH_CDL/RY_ZJH_CXL,4) END 人员证件号查得率,
     RY_ZJH_JFL 人员证件号计费量,
     CASE WHEN RY_ZJH_CDL=0 THEN NULL ELSE ROUND(RY_ZJH_JFL/RY_ZJH_CDL,4) END 人员证件号计费率,
     RY_grBS_CXL 个人标示查询查询量,
     RY_grBS_CDL 个人标示查询查得量,
     CASE WHEN RY_GRBS_CXL=0 THEN NULL ELSE ROUND(RY_GRBS_CDL/RY_GRBS_CXL,4) END 个人标示查询查得率,
     RY_GRBS_JFL 个人标示查询计费量,
     CASE WHEN RY_GRBS_CDL=0 THEN NULL ELSE ROUND(RY_GRBS_JFL/RY_GRBS_CDL,4) END 个人标示查询计费率,
     RY_RYZW_CXL 按职务查询量,
     RY_RYZW_CDL 按职务查得量,
     CASE WHEN RY_RYZW_CXL=0 THEN NULL ELSE ROUND(RY_RYZW_CDL/RY_RYZW_CXL,4) END 按职务查得率,
     RY_RYZW_JFL 按职务计费量,
     CASE WHEN RY_RYZW_CDL=0 THEN NULL ELSE ROUND(RY_RYZW_JFL/RY_RYZW_CDL,4) END 按职务计费率
  FROM
    (SELECT ID_CUSTOMER,TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd') order_date,
      COUNT(*) CXL, --查询量
      SUM(CASE WHEN STATE IN ('1','-3') THEN 1 ELSE 0 END) CDL, --查得量
      SUM(CASE WHEN FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) JFL, --计费量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') THEN 1 ELSE 0 END ) QY_CXL,--企业查询量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_CDL,--企业查询查得量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_JFL,--企业查询计费量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') THEN 1 ELSE 0 END) RY_CXL,--人员查询量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_CDL,--人员查询查得量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) RY_JFL,--人员查询计费量
      SUM(CASE WHEN KEY_TYPE ='2' THEN 1 ELSE 0 END) qy_mc_cxl, --企业查询 按名称查询 查询量
      SUM(CASE WHEN KEY_TYPE ='2' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_MC_CDL, --企业查询 按名称查询 查得量
      SUM(CASE WHEN KEY_TYPE ='2' AND FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_MC_JFL, --企业查询 按名称查询 计费量
      SUM(CASE WHEN KEY_TYPE ='3' THEN 1 ELSE 0 END) qy_ZCH_cxl,--企业查询 按注册号 查询量
      SUM(CASE WHEN KEY_TYPE ='3' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_ZCH_CDL,--企业查询 按注册号 查得量
      SUM(CASE WHEN KEY_TYPE ='3' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_ZCH_JFL,--企业查询 按注册号 计费量
      SUM(CASE WHEN KEY_TYPE ='5' THEN 1 ELSE 0 END) qy_ZZJGDM_cxl,--企业查询 按组织机构代码 查询量
      SUM(CASE WHEN KEY_TYPE ='5' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_ZZJGDM_CDL,--企业查询 按组织机构代码 查得量
      SUM(CASE WHEN KEY_TYPE ='5' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_ZZJGDM_JFL,--企业查询 按组织机构代码 计费量
      SUM(CASE WHEN KEY_TYPE ='13' THEN 1 ELSE 0 END) qy_CREDIT_cxl, --企业查询 按统一社会信用代码 查询量
      SUM(CASE WHEN KEY_TYPE ='13' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_CREDIT_CDL, --企业查询 按统一社会信用代码 查得量
      SUM(CASE WHEN KEY_TYPE ='13' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_CREDIT_JFL, --企业查询 按统一社会信用代码 计费量
      SUM(CASE WHEN KEY_TYPE ='4' THEN 1 ELSE 0 END) ry_ZJH_cxl,--按人员查询 按人员证件号查询 查询量
      SUM(CASE WHEN KEY_TYPE ='4' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_ZJH_CDL,--按人员查询 按人员证件号查询 查得量
      SUM(CASE WHEN KEY_TYPE ='4' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) RY_ZJH_JFL,--按人员查询 按人员证件号查询 计费量
      SUM(CASE WHEN KEY_TYPE ='9' THEN 1 ELSE 0 END) ry_grBS_cxl,--按人员查询 按个人标示查询 查询量
      SUM(CASE WHEN KEY_TYPE ='9' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_GRBS_CDL,--按人员查询 按个人标示查询 查得量
      SUM(CASE WHEN KEY_TYPE ='9' AND FEE_FLAG_INPUT=1  THEN 1 ELSE 0 END) RY_grBS_JFL,--按人员查询 按个人标示查询 计费量
      SUM(CASE WHEN KEY_TYPE ='10' THEN 1 ELSE 0 END) RY_RYZW_CXL,--人员查询 按基本信息 职务查询 查询量
      SUM(CASE WHEN KEY_TYPE ='10' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_RYZW_CDL,--人员查询 按基本信息 职务查询 查得量
      SUM(CASE WHEN KEY_TYPE ='10' AND FEE_FLAG_INPUT=1  THEN 1 ELSE 0 END) ry_RYZW_JFL--人员查询 按基本信息 职务查询  计费量
      FROM  T_ORDER_DETAIL
      WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')  --只统计基本信息查询
        AND ORDER_DATE=v_date
    --and input_key not in ('华为技术有限公司','120103198610290323') --惠信易达用于监控的查询，排除掉
     GROUP BY TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd'),ID_CUSTOMER) T1 
  LEFT JOIN (SELECT DISTINCT ID,FULL_NAME,BRIEF_NAME,saler FROM dim_CUSTOMER) T2 ON T1.ID_CUSTOMER=T2.ID
  UNION ALL
  ---------------------------------中数整体情况-----------------------------------------------
  SELECT ORDER_DATE 订单时间,
     'PTZTQK',
     '平台整体情况',
     '平台整体情况',
     '',
     CXL 查询量,
     CDL 查得量,
     CASE WHEN CXL=0 THEN NULL ELSE ROUND(CDL/CXL,4) END  查得率,
     JFL 计费量,
     CASE WHEN CDL=0 THEN NULL ELSE ROUND(JFL/CDL,4) END  计费率,
     QY_CXL 企业查询量,
     QY_CDL 企业查询查得量,
     CASE WHEN QY_CXL=0 THEN NULL ELSE ROUND(QY_CDL/QY_CXL,4) END  企业查得率,
     QY_JFL 企业查询计费量,
     CASE WHEN QY_CDL=0 THEN NULL ELSE ROUND(QY_JFL/QY_CDL,4) END  企业计费率,
     RY_CXL 人员查询量,
     RY_CDL 人员查询查得量,
     CASE WHEN RY_CXL=0 THEN NULL ELSE ROUND(RY_CDL/RY_CXL,4) END 人员查得率,
     RY_JFL 人员查询计费量,
     CASE WHEN RY_CDL=0 THEN NULL ELSE ROUND(RY_JFL/RY_CDL,4) END 人员计费率,
     QY_MC_CXL 企业名称查询量, 
     QY_MC_CDL 企业名称查得量, 
     CASE WHEN QY_MC_CXL=0 THEN NULL ELSE ROUND(QY_MC_CDL/QY_MC_CXL,4) END 企业名称查得率,
     QY_MC_JFL 企业名称计费量, 
     CASE WHEN QY_MC_CDL=0 THEN NULL ELSE ROUND(QY_MC_JFL/QY_MC_CDL,4) END 企业名称计费率,
     QY_ZCH_CXL 企业注册号查询量,
     QY_ZCH_CDL 企业注册号查得量,
     CASE WHEN QY_ZCH_CXL=0 THEN NULL ELSE ROUND(QY_ZCH_CDL/QY_ZCH_CXL,4) END 企业注册号查得率,
     QY_ZCH_JFL 企业注册号计费量,
     CASE WHEN QY_ZCH_CDL=0 THEN NULL ELSE ROUND(QY_ZCH_JFL/QY_ZCH_CDL,4) END 企业注册号计费率,
     QY_ZZJGDM_CXL 组织机构代码查询量,
     QY_ZZJGDM_CDL 组织机构代码查得量,
     CASE WHEN QY_ZZJGDM_CXL=0 THEN NULL ELSE ROUND(QY_ZZJGDM_CDL/QY_ZZJGDM_CXL,4) END 组织机构代码查得率,
     QY_ZZJGDM_JFL 组织机构代码计费量,
     CASE WHEN QY_ZZJGDM_CDL=0 THEN NULL ELSE ROUND(QY_ZZJGDM_JFL/QY_ZZJGDM_CDL,4) END 组织机构代码计费率,
     QY_CREDIT_CXL 统一社会信用代码查询量,
     QY_CREDIT_CDL 统一社会信用代码查得量,
     CASE WHEN QY_CREDIT_CXL=0 THEN NULL ELSE ROUND(QY_CREDIT_CDL/QY_CREDIT_CXL,4) END 统一社会信用代码查得率,
     QY_CREDIT_JFL 统一社会信用代码计费量,
     CASE WHEN QY_CREDIT_CDL=0 THEN NULL ELSE ROUND(QY_CREDIT_JFL/QY_CREDIT_CDL,4) END 统一社会信用代码计费率,
     RY_ZJH_CXL 人员证件号查询量,
     RY_ZJH_CDL 人员证件号查得量,
     CASE WHEN RY_ZJH_CXL=0 THEN NULL ELSE ROUND(RY_ZJH_CDL/RY_ZJH_CXL,4) END 人员证件号查得率,
     RY_ZJH_JFL 人员证件号计费量,
     CASE WHEN RY_ZJH_CDL=0 THEN NULL ELSE ROUND(RY_ZJH_JFL/RY_ZJH_CDL,4) END 人员证件号计费率,
     RY_grBS_CXL 个人标示查询查询量,
     RY_grBS_CDL 个人标示查询查得量,
     CASE WHEN RY_GRBS_CXL=0 THEN NULL ELSE ROUND(RY_GRBS_CDL/RY_GRBS_CXL,4) END 个人标示查询查得率,
     RY_GRBS_JFL 个人标示查询计费量,
     CASE WHEN RY_GRBS_CDL=0 THEN NULL ELSE ROUND(RY_GRBS_JFL/RY_GRBS_CDL,4) END 个人标示查询计费率,
     RY_RYZW_CXL 按职务查询量,
     RY_RYZW_CDL 按职务查得量,
     CASE WHEN RY_RYZW_CXL=0 THEN NULL ELSE ROUND(RY_RYZW_CDL/RY_RYZW_CXL,4) END 按职务查得率,
     RY_RYZW_JFL 按职务计费量,
     CASE WHEN RY_RYZW_CDL=0 THEN NULL ELSE ROUND(RY_RYZW_JFL/RY_RYZW_CDL,4) END 按职务计费率
  FROM
    (SELECT TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd') order_date,
      COUNT(*) CXL, --查询量
      SUM(CASE WHEN STATE IN ('1','-3') THEN 1 ELSE 0 END) CDL, --查得量
      SUM(CASE WHEN FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) JFL, --计费量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') THEN 1 ELSE 0 END ) QY_CXL,--企业查询量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_CDL,--企业查询查得量
      SUM(CASE WHEN KEY_TYPE IN ('2','3','5','13') AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_JFL,--企业查询计费量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') THEN 1 ELSE 0 END) RY_CXL,--人员查询量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_CDL,--人员查询查得量
      SUM(CASE WHEN KEY_TYPE IN ('4','9','10') AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) RY_JFL,--人员查询计费量
      SUM(CASE WHEN KEY_TYPE ='2' THEN 1 ELSE 0 END) qy_mc_cxl, --企业查询 按名称查询 查询量
      SUM(CASE WHEN KEY_TYPE ='2' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_MC_CDL, --企业查询 按名称查询 查得量
      SUM(CASE WHEN KEY_TYPE ='2' AND FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_MC_JFL, --企业查询 按名称查询 计费量
      SUM(CASE WHEN KEY_TYPE ='3' THEN 1 ELSE 0 END) qy_ZCH_cxl,--企业查询 按注册号 查询量
      SUM(CASE WHEN KEY_TYPE ='3' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_ZCH_CDL,--企业查询 按注册号 查得量
      SUM(CASE WHEN KEY_TYPE ='3' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_ZCH_JFL,--企业查询 按注册号 计费量
      SUM(CASE WHEN KEY_TYPE ='5' THEN 1 ELSE 0 END) qy_ZZJGDM_cxl,--企业查询 按组织机构代码 查询量
      SUM(CASE WHEN KEY_TYPE ='5' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_ZZJGDM_CDL,--企业查询 按组织机构代码 查得量
      SUM(CASE WHEN KEY_TYPE ='5' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_ZZJGDM_JFL,--企业查询 按组织机构代码 计费量
      SUM(CASE WHEN KEY_TYPE ='13' THEN 1 ELSE 0 END) qy_CREDIT_cxl, --企业查询 按统一社会信用代码 查询量
      SUM(CASE WHEN KEY_TYPE ='13' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) QY_CREDIT_CDL, --企业查询 按统一社会信用代码 查得量
      SUM(CASE WHEN KEY_TYPE ='13' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) QY_CREDIT_JFL, --企业查询 按统一社会信用代码 计费量
      SUM(CASE WHEN KEY_TYPE ='4' THEN 1 ELSE 0 END) ry_ZJH_cxl,--按人员查询 按人员证件号查询 查询量
      SUM(CASE WHEN KEY_TYPE ='4' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_ZJH_CDL,--按人员查询 按人员证件号查询 查得量
      SUM(CASE WHEN KEY_TYPE ='4' AND  FEE_FLAG_INPUT=1 THEN 1 ELSE 0 END) RY_ZJH_JFL,--按人员查询 按人员证件号查询 计费量
      SUM(CASE WHEN KEY_TYPE ='9' THEN 1 ELSE 0 END) ry_grBS_cxl,--按人员查询 按个人标示查询 查询量
      SUM(CASE WHEN KEY_TYPE ='9' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_GRBS_CDL,--按人员查询 按个人标示查询 查得量
      SUM(CASE WHEN KEY_TYPE ='9' AND FEE_FLAG_INPUT=1  THEN 1 ELSE 0 END) RY_grBS_JFL,--按人员查询 按个人标示查询 计费量
      SUM(CASE WHEN KEY_TYPE ='10' THEN 1 ELSE 0 END) RY_RYZW_CXL,--人员查询 按基本信息 职务查询 查询量
      SUM(CASE WHEN KEY_TYPE ='10' AND  STATE IN ('1','-3') THEN 1 ELSE 0 END) RY_RYZW_CDL,--人员查询 按基本信息 职务查询 查得量
      SUM(CASE WHEN KEY_TYPE ='10' AND FEE_FLAG_INPUT=1  THEN 1 ELSE 0 END) ry_RYZW_JFL--人员查询 按基本信息 职务查询  计费量
      FROM  T_ORDER_DETAIL
      WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')  --只统计基本信息查询
        AND ORDER_DATE=v_date
    --and input_key not in ('华为技术有限公司','120103198610290323') --惠信易达用于监控的查询，排除掉
     GROUP BY TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd')) T1;
  COMMIT;
  PRO_LOG('P_ETL_BI_DAILY','抽取'||V_DATE||'运营分析的日报数据结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
COMMIT;
PRO_LOG('P_ETL_BI_DAILY','抽取'||V_BEGIN||'到'||V_END||'运营分析的日报数据结束');
END P_ETL_BI_DAILY;
/

