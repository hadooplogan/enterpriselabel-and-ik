CREATE PROCEDURE P_ETL_ALI_DAILY (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_ALI_DAILY
--PURPOSE: 生成阿里日报统计，区分企业查询结果的法人是否为空.阿里已不需要
--CREATOR： 夏培娟
--DATE:    2016-12-2
-------------------------------------------------------------
BEGIN
PRO_LOG('P_ETL_ALI_DAILY','抽取'||V_BEGIN||'到'||V_END||'日报开始');
  /**V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  ---删除当天已有日报数据
  DELETE FROM DM_ALI_DAILY WHERE   ORDER_DATE=V_DATE;
  COMMIT;
  --插入当天日报数据
    INSERT INTO DM_ALI_DAILY
      (ORDER_DATE,
      ID_CUSTOMER,
      CUST_FULL_NAME,
      U_ID,
      UKEY_NO,
      ID_USER,
      USER_NAME,
      CRENO_NOT_NULL,
      CRENO_NULL
      )
  SELECT ORDER_DATE,
     ID_CUSTOMER,
     CUST_FULL_NAME,
     U_ID,
     UKEY_NO,
     ID_USER,
     USER_NAME,
     SUM(CASE WHEN PERson_id IS NOT NULL THEN 1 ELSE 0 END) CRENO_NOT_NULL,--证件号都清掉了
     SUM(CASE WHEN PERson_id IS  NULL THEN 1 ELSE 0 END) CRENO_NULL
  FROM DW_ORDER_DETAIL
  WHERE FEE_FLAG_INPUT=1 --计费订单
    AND KEY_TYPE IN ('2','3','5','13') --企业查询
    AND PRODUCT_TPL_CODE IN ('1','10','11','12') --基本查询
    AND ID_CUSTOMER='CID_00003985' --阿里巴巴
    AND ORDER_DATE=V_DATE
  GROUP BY ORDER_DATE,ID_CUSTOMER,CUST_FULL_NAME,U_ID,UKEY_NO,ID_USER,USER_NAME;
  
  COMMIT;
  PRO_LOG('P_ETL_ALI_DAILY','抽取'||V_DATE||'日报结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
COMMIT;**/
NULL;

PRO_LOG('P_ETL_ALI_DAILY','抽取'||V_BEGIN||'到'||V_END||'日报结束');

END P_ETL_ALI_DAILY;
/

