CREATE FUNCTION FUC_CM_ISREGNO(
  v_REGNO in varchar2
)
RETURN INT
---------------------------------------------------------------------------
  -- 函数名称: FUC_CM_ISREGNO
  -- 来源: 数据工厂wgz
  -- 功能描述: 验证是否为有效的 工商注册号
  --           返回值：0 为有效 ，1 为无效
  -- 版 本 号: v1.0.0
  -- 备    注:
  -- 修改历史:
  --
  -- 版本: wgz 2017-01-11
  -- 版权: 中数智汇
---------------------------------------------------------------------------
IS --/* 变量声明 */
  CHK_RSL    INT DEFAULT 1; --默认状态为 无效--
  I INTEGER  DEFAULT 0;  ---循环变量
  V_NUM      INT DEFAULT 0;  -- 临时变量
BEGIN
  --/* 函数主体 */

  -- 如果注册号位数不为15位，则直接返回1
  IF( LENGTH(v_REGNO) <> 15 or v_REGNO is null) THEN
     RETURN 1;
  END IF ;

  -- 如果区域代码（身份证前2位为省）不是合法的，则直接返回
  IF( substr(v_REGNO,1,2) not in ( '10','11','12','13','14','15','21','22','23','31','32','33','34','35','36','37','41','42','43','44','45','46','50','51','52','53','54','61','62','63','64','65'))
    THEN RETURN 1 ;
  END IF ;

  --- 数值检验
  IF ( replace(translate(v_REGNO,'1234567890','0000000000'),'0','') is not null ) THEN
    RETURN 1;
  END IF;

  --- 校验位X处理
  --I=1时;
  V_NUM := mod(2*nvl(nullif(mod(substr(v_REGNO,1,1)+10,10),0),10),11);
  -- 2 <= I <= 14时
  I := 2;
  WHILE I < LENGTH(v_REGNO) LOOP
     V_NUM := mod( 2*nvl( nullif( mod( substr(v_REGNO, I, 1) + V_NUM, 10), 0),10), 11);
     I := I + 1;
  END LOOP;
  -- 校验码
  V_NUM := mod(11 - V_NUM, 10);
  IF ( V_NUM <> to_number(substr(v_REGNO,15,1)) ) THEN
    RETURN 1;
  END IF;

  CHK_RSL := 0;
  RETURN CHK_RSL;

EXCEPTION
  when others then
  return 1;
END FUC_CM_ISREGNO;
/

