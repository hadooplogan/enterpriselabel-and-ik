CREATE PROCEDURE P_ETL_CALL (V_BEGIN VARCHAR2,V_END VARCHAR2,IS_RUN_MONTH VARCHAR2,V_MONTH VARCHAR2,V_CONTRACT VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_CALL
--PURPOSE: 统一调度，执行存储过程
--CREATOR： 夏培娟
--DATE:    2017-03-07
--PARAM:   V_BEGIN:前一天时间，格式YYYYMMDD ；
--         V_END:前一天时间，格式YYYYMMDD；
--         IS_RUN_MONTH:Y/N,每月1号时标志为Y；
--         V_MONTH:IS_RUN_MONTH='Y'时，此参数有用，处理上月数据，格式YYYYMM;
--         V_CONTRACT:IS_RUN_MONTH='Y'时，此参数有用,生成账单中的账期，当月的账期，不是上个月的账期；
-------------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DATE('''||V_BEGIN||''','''||V_END||'''); END;';   --时间维表插入数据，默认插入执行程序当天的时间
  P_PINGAN_USER;
  EXECUTE IMMEDIATE 'BEGIN P_ETL_INSERT_CUS;END;';   --更新客户维表，没有时间参数，存储过程内部取系统时间，记录更改记录的时间
  EXECUTE IMMEDIATE 'BEGIN P_ETL_CONTRACT_QIDIAN; END;';--生成企典的合同信息,向维度表dim_customer中插入3.0平台新增的客户
  EXECUTE IMMEDIATE 'BEGIN P_ETL_FEE('''||V_BEGIN||''','''||V_END||'''); END;';--处理计费标志
  EXECUTE IMMEDIATE 'BEGIN P_ETL_RELATIONS_PARAM_40('''||V_BEGIN||''','''||V_END||'''); END;'; --处理所有关联洞察的参数
  P_ETL_PARAM_QIDIAN (V_BEGIN,V_END);--处理单独客户的参数，拆分简化查询参数
  EXECUTE IMMEDIATE 'BEGIN P_ETL_FEE_QIDIAN('''||V_BEGIN||''','''||V_END||'''); END;';--处理企典的计费标志
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_ADD_QIDIAN('''||V_BEGIN||''','''||V_END||'''); END;';--将2.5和3.0平台合并，生成日报.因为月报生成比较慢，可能会影响日报发送，所以调到月报前面
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_NEW('''||V_BEGIN||''','''||V_END||'''); END;';--只统计3.0平台的数据
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_OLD('''||V_BEGIN||''','''||V_END||'''); END;';--只统计2.5平台的数据
  
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_RELATION('''||V_BEGIN||''','''||V_END||'''); END;';--关联关系日报**/
  --P_ETL_MONTH_ADD_QIDIAN_CUR(IS_RUN_MONTH,V_MONTH); --游标处理月报中的按用户统计表
  EXECUTE IMMEDIATE 'BEGIN P_ETL_MONTH_ADD_QIDIAN('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--将2.5和3.0平台合并，生成月报数据
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_MONTH_ADD_QIDIAN_CUS_ZZ('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--中证征信 9月份特殊处理
  
  EXECUTE IMMEDIATE 'BEGIN P_ETL_CONTRACT('''||IS_RUN_MONTH||''','''||V_CONTRACT||'''); END;';--处理账单的账期，每月1号处理当月数据，是否执行在存储过程内控制
  EXECUTE IMMEDIATE 'BEGIN P_ETL_LEIJI_ADD_QIDIAN('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--将2.5和3.0平台合并，生成累计数据
  EXECUTE IMMEDIATE 'BEGIN P_ETL_CUSTNAME('''||V_BEGIN||'''); END;'; --参数只是在写日志时记录是何时更新的 209目前除了订单表外，只更新t_customer
  EXECUTE IMMEDIATE 'BEGIN DM_REGCAP_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按注册资本统计
  EXECUTE IMMEDIATE 'BEGIN DM_PROVINCE_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按省份统计
  EXECUTE IMMEDIATE 'BEGIN DM_INDUSTRY_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按行业统计  
  EXECUTE IMMEDIATE 'BEGIN P_ETL_ALI_DAILY('''||V_BEGIN||''','''||V_END||'''); END;';--生成阿里日报统计，区分企业查询结果的法人是否为空
  EXECUTE IMMEDIATE 'BEGIN P_ETL_BI_DAILY_NEW('''||V_BEGIN||''','''||V_END||'''); END;';--生成运营分析的日报数据
  EXECUTE IMMEDIATE 'BEGIN P_ETL_RESPONSE_DAILY('''||V_BEGIN||''','''||V_END||'''); END;';--响应时间汇总表
  EXECUTE IMMEDIATE 'BEGIN P_ETL_ORDER_COUNT('''||V_BEGIN||''','''||V_END||'''); END;';--2.5平台订单统计
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_IS_LEGAL('''||V_BEGIN||''','''||V_END||'''); END;';--2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，查询关键字是否合法.0为合法，1为不合法
  
END P_ETL_CALL;
/

