CREATE PROCEDURE P_ALI_REPEAT AS 
BEGIN
INSERT INTO ALI_20160715_OUTPUT_REPEAT
select o.regno,i.credit,o.entname,o.name,o.cerno from ali_20160715_output o 
inner join (select * from ali_input_20160720 
            where regno in (select regno from ali_input_20160720 
                         where regno is not null 
                         group by regno having count(*)>1)) i on o.regno=i.regno
where o.regno is not null;
commit;
END P_ALI_REPEAT;
/

