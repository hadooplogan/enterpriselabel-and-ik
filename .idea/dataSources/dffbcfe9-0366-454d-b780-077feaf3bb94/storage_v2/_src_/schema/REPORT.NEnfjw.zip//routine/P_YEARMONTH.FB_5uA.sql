CREATE PROCEDURE P_yearmonth  AS
 V_YM VARCHAR2(20) :=TO_CHAR(SYSDATE,'yyyymm');
 v_month varchar2(20) := substr(to_char(SYSDATE,'yyyymmdd'),1,4)||'年'||case when substr(to_char(SYSDATE,'yyyymmdd'),5,1)='0' then substr(to_char(SYSDATE,'yyyymmdd'),6,1) else substr(to_char(SYSDATE,'yyyymmdd'),5,2) end ||'月份对账单';
 BEGIN
DELETE FROM YEARMONTH WHERE YM=V_YM;
COMMIT;
insert into yearmonth (ym,date2) values(v_ym,v_month);
commit;
end;
/

