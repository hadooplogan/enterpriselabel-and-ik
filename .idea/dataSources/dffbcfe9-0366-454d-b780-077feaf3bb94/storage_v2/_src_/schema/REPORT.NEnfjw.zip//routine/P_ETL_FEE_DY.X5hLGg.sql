CREATE PROCEDURE P_ETL_FEE_DY (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  CNT NUMBER;
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_DY
--PURPOSE: 东亚银行集团族谱从2016-01-01开始去重  之前明细把2016-01-01至2016-06-30之间的订单删除了
--CREATOR： 夏培娟
--DATE:    2017-12-18
-------------------------------------------------------------
PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  -----------1.8、东亚银行：集团族谱去重-------------------
  UPDATE DW_ORDER_DETAIL T
  SET FEE_FLAG_RS=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL
     WHERE PRODUCT_TPL_CODE ='5'--集团族谱去重
       AND FEE_FLAG_RS='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN '20160101' AND V_DATE --东亚银行（中国）有限公司 集团族谱去重时间：2016/1/1-2017/12/31
       AND ID_CUSTOMER IN ('CID_00004783') --东亚银行
     GROUP BY RS_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE ='5'--集团族谱去重
    AND FEE_FLAG_RS='1'
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER  ='CID_00004783'; --东亚银行
  COMMIT;
  
  -----------2.8、东亚银行：集团族谱去重-------------------
  UPDATE DW_ORDER_DETAIL T
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL
     WHERE PRODUCT_TPL_CODE ='5'--集团族谱去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN '20160101' AND V_DATE --东亚银行（中国）有限公司 集团族谱去重时间：2016/1/1-2017/12/31
       AND ID_CUSTOMER IN ('CID_00004783') --东亚银行
     GROUP BY INPUT_KEY,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE ='5'--集团族谱去重
    AND FEE_FLAG_INPUT='1'
    AND ORDER_DATE=V_DATE
    AND ID_CUSTOMER  ='CID_00004783' ;--东亚银行
  COMMIT;
  
  PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，处理'||V_DATE||'的订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');


END P_ETL_FEE_DY;
/

