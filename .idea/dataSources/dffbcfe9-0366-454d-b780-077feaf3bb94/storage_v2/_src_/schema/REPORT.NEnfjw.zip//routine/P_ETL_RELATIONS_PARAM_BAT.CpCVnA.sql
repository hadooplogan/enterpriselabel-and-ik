CREATE PROCEDURE P_ETL_RELATIONS_PARAM_BAT (V_BEGIN VARCHAR2,V_END VARCHAR2)  AS
V_DATE VARCHAR2(10);
V_CN NUMBER;               --查询对象个数
I NUMBER;
TEMP_PARAM VARCHAR2(2000); 
V_PARAM VARCHAR2(2000);    --查询对象
-------------------------------------------
--NAME: P_ETL_RELATIONS_PARAM_BAT
--PURPOSE:处理多节点关联关系参数的顺序问题,关联关系默认去重 批量处理新增客户的数据
--CREATOR： 夏培娟
--DATE:    2017-09-27
-------------------------------------------
BEGIN
  
  PRO_LOG('P_ETL_RELATIONS_PARAM_BAT','处理'||V_BEGIN||'到'||V_END||',的关联洞察查询参数开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  --------------------处理多节点关联关系------------------------
  --定义游标，一次处理一天
  DECLARE
  CURSOR C_RELATIONS IS
  select order_no
  FROM DW_ORDER_qidian
  WHERE ORDER_DATE = V_DATE
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('asyn_muti_nodes','muti_nodes')
    AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION );

  C_ROW   C_RELATIONS%ROWTYPE;
  --打开游标，每次循环处理一行
  BEGIN
  OPEN C_RELATIONS;
    LOOP
      FETCH C_RELATIONS INTO C_ROW;
      --处理为行
      DELETE FROM DW_RELATIONS_TEMP;
      COMMIT;
      --一行变为多行，同时根据参数排序赋值
      INSERT INTO DW_RELATIONS_TEMP
        (C_SORT, ORDER_NO, PARAM, PARAM_ONE)
      SELECT ROWNUM C_SORT,ORDER_NO,PARAM,PARAM_ONE
      FROM
        (SELECT ORDER_NO,
          PARAM,
          REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL) PARAM_ONE
         FROM
           (SELECT ORDER_NO,
              PARAM,
              FUN_PARAM(PARAM) PARAM_BRIEF
            FROM DW_ORDER_QIDIAN
            WHERE ORDER_DATE = V_DATE
              AND ORDER_NO     =C_ROW.ORDER_NO
           )
        CONNECT BY LEVEL<LENGTH(PARAM_BRIEF)-LENGTH(REPLACE(PARAM_BRIEF,',',''))+2
        ORDER BY REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL)
        );
        COMMIT;
      --将多行变为一行
      SELECT COUNT(*) INTO V_CN
      FROM DW_RELATIONS_TEMP;
      
      V_PARAM:='';
      --开始循环处理查询参数
      FOR I IN 1..V_CN LOOP
        BEGIN
        SELECT PARAM_ONE INTO TEMP_PARAM
        FROM DW_RELATIONS_TEMP
        WHERE C_SORT=I;
        END;
        
        V_PARAM:=V_PARAM||','||TEMP_PARAM;
      END LOOP;
      
      UPDATE DW_ORDER_QIDIAN
      SET PARAM_CN=V_CN,PARAM_AFTER=SUBSTR(V_PARAM,2),--因为初始赋值为空，所以多一个逗号
        PARAM_LAYER=SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8,INSTR(PARAM,'"relations":')-INSTR(PARAM,'"layer":')-9),--提取出层级
        FUNCTIONCODE_AFTER='muti_nodes'
      WHERE ORDER_DATE=V_DATE
        AND ORDER_NO=C_ROW.ORDER_NO;
      COMMIT;
      
      EXIT WHEN C_RELATIONS%NOTFOUND;
    END LOOP;
  CLOSE C_RELATIONS;
  
   -------------处理控制路径、实质关联、族谱的查询参数-----------------
  BEGIN
  ---------------控制路径-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=SUBSTR(PARAM,13,INSTR(PARAM,'"relations":')-15),--只有企业名称，不涉及层级
    FUNCTIONCODE_AFTER='control_path'
  WHERE ORDER_DATE = V_DATE
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('control_path','asyn_control_path')
    AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION );
  COMMIT;
  
  ---------------实质关联-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=SUBSTR(PARAM,13,INSTR(PARAM,'"layer":')-15),--只有企业名称，不涉及层级
    FUNCTIONCODE_AFTER='real_relation'
  WHERE ORDER_DATE = V_DATE
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('real_relation','asyn_real_relation')
    AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION );
  COMMIT;
  
  ---------------族谱-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=SUBSTR(PARAM,13,INSTR(PARAM,'"layer":')-15),
    PARAM_LAYER=SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8,INSTR(PARAM,'"relations":')-INSTR(PARAM,'"layer":')-9),
    FUNCTIONCODE_AFTER='genealogy'
  WHERE ORDER_DATE = V_DATE
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('genealogy','asyn_genealogy')
    AND CUSTOMERID in (SELECT ID_CUSTOMER_3 FROM DIM_CUSTOMER_UNION );
  COMMIT;
  
  END;
  
  END;
  PRO_LOG('P_ETL_RELATIONS_PARAM_BAT','处理'||V_DATE||',的关联洞察查询参数结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
END P_ETL_RELATIONS_PARAM_BAT;
/

