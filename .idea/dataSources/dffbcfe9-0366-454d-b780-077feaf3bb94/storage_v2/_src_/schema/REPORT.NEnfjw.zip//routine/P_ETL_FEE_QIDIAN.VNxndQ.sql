CREATE PROCEDURE P_ETL_FEE_QIDIAN (V_QIDIAN_BEGIN VARCHAR2,V_QIIDAN_END VARCHAR2) AS
 V_DATE VARCHAR2(8);
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_QIDIAN
--PURPOSE: 3.0平台订单去重计费:每天增量处理计费标志
--CREATOR： 夏培娟
--DATE:    2017-03-16
--美团，企业查询当月去重。
--账单不去重的客户：
--  2c91808859631139015a114a430116cb，兴业银行，企业查询和企典，不去重 去重，此信息有误
--  2c9180965876381d0158b3bd657a0290，  国家开发银行股份有限公司，企业查询和人员查询不去重
--  2c9180aa5ab13a58015aff0e82410079,长沙银行 集团族谱不去重
--ff80808156e456ec0156e458cdec0000 阿里巴巴 不去重
--亚联数据 UID：SMDFYUWE 改为亚联数据吉林银行专用,不去重,是因为只有企典通用版. UID：OQLJZQHS  按月去重，请处理，非常感谢！
--惠信易达 在2.5平台上关联关系去重，3.0上暂未设置
--企典专业版：默认不去重，企典通用版：默认不计费。企业查询、人员查询默认去重
--remark:  只处理有出账需求的客户数据，因为3.0的参数特别长，并且是接口用户，调用量特别大，如阿里，故为减轻系统负担只对有出账需求的客户去重计费
--客户出账说明：美团从2017-2-24开始正式使用系统，出账；
--上海敬众，数据核验去重，jephy提出的需求
--上海申久从2018年2月27日开始计费，不去重。
--长沙银行从2月8日开始计费，企业查询按月去重，集团族谱按月去重。
--美团：美团支付和美团到家分开去重，20180402确定，从2017-09开始重新处理数据
-------------------------------------------------------------
 PRO_LOG('P_ETL_FEE_QIDIAN','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||'订单的计费标志开始');
 
 /**--安徽智安信,从2017-09-04关联洞察开始计费
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE PRODUCTCODE='relations'
    AND CUSTOMERID ='2c9180b75d63a388015d7d997a901a4c'
    AND ORDER_DATE<'20170904';
  
  --美团支付 20170925 18:00切换，之后计费，之前的不计费
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='43UJUZHM'
    AND ORDER_DATE BETWEEN '20170901' AND '20170924'
    AND CUSTOMERID='2c91809959630547015a3553a5770322';
  COMMIT;
  
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='43UJUZHM'
    AND ORDER_DATE = '20170925'
    AND STARTTIME<=TO_DATE('2017-09-25 18:00:00','yyyy-mm-dd hh24:mi:ss')
    AND CUSTOMERID='2c91809959630547015a3553a5770322';
  COMMIT;**/
  
  V_DATE:=V_QIDIAN_BEGIN;
  WHILE V_DATE<=V_QIIDAN_END LOOP
  BEGIN
  
  --标签是测试用户的不计费
  update DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE user_tag like '%测试用户%'
    AND ORDER_DATE=V_DATE;
  COMMIT;
   --------------联源智信10001017试用100条，迁移客户uid不变------
  update DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='541C07F1F3108A1B' --ukey_no ='10001017'
    and CUSTOMERID ='2c91808858fb433a01590243d214000' --联源智信
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ------------江苏银行 CID_00000027,专线用户虚拟ukey179,测试账号不计费，1000条用量
  update DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='C60E47F3A185D678'--ukey_no ='专线用户虚拟ukey179'
    and CUSTOMERID ='2c91808859631139015a8d080e513526'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --------------南京银行10002513关联关系和集团族谱各可试用10条------
  update DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE  PRODUCTCODE in ('relation','relations')
    and UUID='16D01D4D70838E9F'-- ukey_no ='10002513'
    and CUSTOMERID ='2c9180915aaa493a015b6040189a03e8' --南京银行
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  /**-------------- 东方金诚，3.0平台仅人员核验开始计费------现在全部计费
  update DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE  PRODUCTCODE not in ('verify')
    and CUSTOMERID ='2c9180b75c0b0c2c015cc49be74b5342' 
    AND ORDER_DATE=V_DATE;
  COMMIT;**/
  
  /**----------融宝支付账号UID：S89AXYCU是3.0平台的测试账号，测试500条数据，不计费.从2017.9.21开始计费---
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='S89AXYCU'
    AND CUSTOMERID='2c9180b75c0b0c2c015c77c113f04683'
    AND ORDER_DATE=V_DATE;
  COMMIT;**/
  
  -----广发银行，30天去重----
  -----------工商银行CID_00000009，2c9180965876381d0158aa2a50ed025d,测试账户34B1AB58E4B5FB39	10002977不计费----------
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID='34B1AB58E4B5FB39'
    AND CUSTOMERID='2c9180965876381d0158aa2a50ed025d'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ---------交通银行 CID_00000059，基本查询只以下用户计费：专线用户虚拟ukey140、00001699、00001703、00001709、00001731、00001748、00002406
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID NOT IN ('CABDECD128CB1104','209BF60EED4F81F3','1BD5CEC52794D7F4','01E5D4D2ABADEFD1',
    'C9CC25789903D219','1D596897D91AAF68','18F813AB86EAD978')
    AND PRODUCTCODE in ('enterprise-datasource','newperson')   --基本查询
    AND CUSTOMERID ='2c9180aa5ab13a58015aff049cf0000d'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  ---------上海银行的界面用户 目前22个界面用户  只有一个10001794收费 其余21个界面用户都是试用账户-----
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE UUID <>'FD7174DB09C4E0A8'
    AND CUSTOMERID ='2c9180be5e3b4367015e3b783e860054' --上海银行股份有限公司
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------京东金融此账户不计费 10002234:C8034C6CD9CCAFDF--------------
  --ZPDKZYHA，不计费 
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE UUID  in ('C8034C6CD9CCAFDF','ZPDKZYHA') --第一个是暂不计费('专线用户虚拟ukey116'从2017-01-20开始计费) 第二个是测试账户，不计费
    and customerid='2c9180b75c0b0c2c015c0b2f68100006' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------10002438:C7C6D1E194DA5383,从2017-3-15开始计费,但是作为浦发卡中心，jephy手工处理
  -------10002859:35B2DE1B4DDF43C3,从2017-04-17开始
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE UUID in ('C7C6D1E194DA5383','35B2DE1B4DDF43C3') --不计费 此账户一直不计费
    and customerid='2c9180c25dea8e29015e0386d3351622' --
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --天行数科2c9180bb5cd46198015ced420a0410a1，关联洞察不计费，其他从2017-10-01开始计费
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE productcode='relations' --不计费 
    and customerid='2c9180bb5cd46198015ced420a0410a1'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --天道计然2c9180bb5cd46198015d2a61582d4350，用户名：tdtest，UID：NJFADKQA 限量50条，不计费
  UPDATE DW_ORDER_qidian
  SET FEE_FLAG=0
  WHERE UUID='NJFADKQA' --不计费 
    and customerid='2c9180bb5cd46198015d2a61582d4350'
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --企典通用版，只有id和name，一般不计费
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE functioncode ='enterpriseListBasic' --企典通用版
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --关联关系3.1以下功能不计费--
  UPDATE DW_ORDER_QIDIAN
  SET FEE_FLAG=0
  WHERE functioncode in ('order_status','result','status','statistics') --单个订单状态查询/异步请求订单结果/异步请求订单状态/企业统计信息查询
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  --重新处理企业查询的参数，删掉version和mask
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=NVL(SUBSTR(PARAM,1,INSTR(PARAM,'"version":')-1),SUBSTR(PARAM,1,INSTR(PARAM,'"mask":')-1))
  WHERE PRODUCTCODE IN ('enterprise-datasource')
    AND ORDER_DATE=V_DATE;
  COMMIT;
    
  -----------1.1、企业查询、人员查询-------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource','newperson')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID NOT IN ('2c9180c25dea8e29015e13c4a4ad59ce','2c9180c25dea8e29015e13d4b21b5c72','2c9180b75c0b0c2c015caa8ccf2950db','2c9180c25dea8e29015e037c573d1620','2c9180965876381d0158b3bd657a0290','ff80808156e456ec0156e458cdec0000','2c91ea9960fe99c3016107d8f0ef3d16','2c9180a95d833fcd015d9673f00d0162','2c91809959630547015a3553a5770322') --兴业银行企业查询和企典不去重，兴业信用卡不去重，民生信用卡不去重，招商银行,国家开发银行股份有限公司不去重，广发银行30天去重，台州银行3个月去重(从2017-10开始按月去重) 圣盈信不去重 美团：美团支付和美团到家分开去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param),PRODUCTCODE
    )
    AND PRODUCTCODE in ('enterprise-datasource','newperson')
    AND FEE_FLAG='1'
    AND CUSTOMERID NOT IN ('2c9180c25dea8e29015e13c4a4ad59ce','2c9180c25dea8e29015e13d4b21b5c72','2c9180b75c0b0c2c015caa8ccf2950db','2c9180c25dea8e29015e037c573d1620','2c9180965876381d0158b3bd657a0290','ff80808156e456ec0156e458cdec0000','2c91ea9960fe99c3016107d8f0ef3d16','2c9180a95d833fcd015d9673f00d0162','2c91809959630547015a3553a5770322') --兴业银行，企业查询和企典，不去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -----------1.2、企业查询 美团支付和美团到家分开去重 -------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource','newperson')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID ='2c91809959630547015a3553a5770322' --美团：美团支付和美团到家分开去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY uuid,nvl(param_after,param),PRODUCTCODE
    )
    AND PRODUCTCODE in ('enterprise-datasource','newperson')
    AND FEE_FLAG='1'
    AND CUSTOMERID ='2c91809959630547015a3553a5770322' --美团：美团支付和美团到家分开去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------------1.2关联关系 默认去重，并重新处理参数------------------
  --亚联数据，关联关系去重
  --安徽智安信和 亚联数据关联洞察计费均按查询企业名称按月去重。
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('relations','relation')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID not in ('2c918088596311390159d35fa1ef13bf','2c91ea9960fe99c3016107d8f0ef3d16','2c9180a95d833fcd015d9673f00d0162') --长沙银行：集团族谱不去重；前海征信：关联关系30天去重 
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param),nvl(functioncode_after,functioncode)
    )
    AND PRODUCTCODE in ('relations','relation')
    AND FEE_FLAG='1'
    AND CUSTOMERID  not in ('2c918088596311390159d35fa1ef13bf','2c91ea9960fe99c3016107d8f0ef3d16','2c9180a95d833fcd015d9673f00d0162') --长沙银行：集团族谱不去重；前海征信：关联关系30天去重 
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -----------1.3、上海敬众数据核验去重：当月去重（数据核验默认不去重）-------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE ='verify'
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID='2c9180aa5ab13a58015aff6809480243' --上海敬众id
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,param
    )
    AND PRODUCTCODE ='verify'
    AND FEE_FLAG='1'
    AND CUSTOMERID='2c9180aa5ab13a58015aff6809480243' 
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -----------1.4、广发银行 30天去重-------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource','newperson')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID ='2c9180c25dea8e29015e037c573d1620' --广发银行30天去重
       AND ORDER_DATE BETWEEN TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')-29,'yyyymmdd') AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param),PRODUCTCODE
    )
    AND PRODUCTCODE in ('enterprise-datasource','newperson')
    AND FEE_FLAG='1'
    AND CUSTOMERID  ='2c9180c25dea8e29015e037c573d1620' --兴业银行，企业查询和企典，不去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  /**-----------1.5、台州银行 3个月去重-------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource','newperson')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID ='2c9180c25dea8e29015e277d90bf6976' --广发银行30天去重
       AND ORDER_DATE BETWEEN '20171001' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,param,PRODUCTCODE
    )
    AND PRODUCTCODE in ('enterprise-datasource','newperson')
    AND FEE_FLAG='1'
    AND CUSTOMERID  ='2c9180c25dea8e29015e277d90bf6976' --兴业银行，企业查询和企典，不去重
    AND ORDER_DATE=V_DATE;
  COMMIT;**/
  
    -------------1.6前海征信 关联关系 30天去重------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE ORDER_NO not IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('relations','relation')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID  in ('2c918088596311390159d35fa1ef13bf') --前海征信：关联关系30天去重
       AND ORDER_DATE BETWEEN TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')-29,'yyyymmdd')  AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param),nvl(functioncode_after,functioncode)
    )
    AND PRODUCTCODE in ('relations','relation')
    AND FEE_FLAG='1'
    AND CUSTOMERID   in ('2c918088596311390159d35fa1ef13bf') --长沙银行 集团族谱不去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------------2.1 华融资产 正常去重之后，再跨产品去重------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE nvl(param_after,param)  IN 
    (SELECT nvl(param_after,param)
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID ='2c9180c25dea8e29015e37e2135c7e56' --华融资产跨产品去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param)
    )
    AND PRODUCTCODE not in ('enterprise-datasource')
    AND FEE_FLAG='1'
    AND CUSTOMERID  ='2c9180c25dea8e29015e37e2135c7e56' --华融资产跨产品去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_QIDIAN','按照查询参数去重，处理'||V_DATE||'订单的计费标志结束');

  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_QIDIAN','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||'订单的计费标志结束');
  
END P_ETL_FEE_QIDIAN;
/

