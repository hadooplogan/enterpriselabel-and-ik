CREATE PROCEDURE P_ETL_DETAIL_LIST (V_BEGIN VARCHAR2,V_END VARCHAR2)AS 
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_DETAIL_LIST
--PURPOSE: 生成账单中的明细表信息，为提升速度
--CREATOR： 夏培娟
--DATE:    2016-09-01
-------------------------------------------------------------
BEGIN
  PRO_LOG('P_ETL_DETAIL_LIST','抽取'||V_BEGIN||'到'||V_END||'账单明细开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  ---删除当天已有日报数据
  DELETE FROM T_ORDER_DETAIL_LIST WHERE 订单日期=substr(V_DATE,1,4)||'-'||substr(V_DATE,5,2)||'-'||substr(V_DATE,7,2);
  COMMIT;
INSERT INTO T_ORDER_DETAIL_LIST
  (
  客户名称,
  机构名称,
  机构ID,
  用户名称,
  用户ID,
  用户UID,
  订单号,
  客户订单号,
  订单日期,
  订单发送日期,
  订单返回日期,
  产品名称,
  查询模块,
  输入条件,
  查询对象,
  成功标志,
  收费标志,
  ID_CUSTOMER,
  YYMONTH,
  REMARK,
  UKEY_NO,
  key_type
  )
SELECT 
  CUST_FULL_NAME 客户名称,
  ORG_FULL_NAME 机构名称,
  ID_ORG 机构ID,
  USER_NAME 用户名称,
  ID_USER 用户ID,
  U_ID 用户UID,
  ORDER_NO 订单号,
  ALI_ID 客户订单号,
  TO_CHAR(to_date(V_DATE,'yyyy-mm-dd'),'yyyy-mm-dd')  订单日期,
  TO_CHAR(SUBMIT_TIME,'yyyy-mm-dd hh24:mi:ss') 订单发送日期,
  TO_CHAR(FINISH_TIME,'yyyy-mm-dd hh24:mi:ss') 订单返回日期,
  PRODUCT_TPL_NAME 产品名称,
  ORDER_TYPE 查询模块,
  INPUT_KEY 输入条件,
  UNIQUE_KEY 查询对象,
  CASE WHEN STATE IN ('1','-3') THEN '成功' ELSE '失败' END 成功标志,
  CASE WHEN FEE_FLAG_INPUT=1 THEN '计费' ELSE '不计费' END 收费标志,
  ID_CUSTOMER,
  YYMONTH,
  REMARK,
  UKEY_NO,
  t2.c_name
FROM T_ORDER_DETAIL T1
left join T_TYPE_LIST t2 on t1.key_type=t2.c_code
WHERE ORDER_DATE =V_DATE ;

  COMMIT;
  PRO_LOG('P_ETL_DETAIL_LIST','抽取'||V_DATE||'账单明细结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END LOOP;
  COMMIT;
PRO_LOG('P_ETL_DETAIL_LIST','抽取'||V_BEGIN||'到'||V_END||'账单明细结束');

END P_ETL_DETAIL_LIST;
/

