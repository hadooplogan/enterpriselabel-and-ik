CREATE PROCEDURE P_ETL_XINGYE_201801 AS 
-------------------------------------------------------------
--NAME:    P_ETL_XINGYE_201801
--PURPOSE: 兴业银行,201801，界面和接口都有查询的话寄到界面用户下
--CREATOR： 夏培娟
--DATE:    2018-02-07
-------------------------------------------------------------
BEGIN
  UPDATE DW_ORDER_DETAIL t
  SET FEE_FLAG_INPUT=0
  WHERE input_key IN  
        (SELECT input_key 
         FROM DW_ORDER_DETAIL 
         WHERE ORDER_FROM IN ('0')
           AND FEE_FLAG_INPUT=1
           AND ID_CUSTOMER='CID_00000107'
           AND ORDER_DATE BETWEEN '20180101' AND '20180131'
        )
    AND ORDER_FROM IN ('1','2')
    AND FEE_FLAG_INPUT=1
    AND ID_CUSTOMER='CID_00000107'
    AND ORDER_DATE BETWEEN '20180101' AND '20180131';
  COMMIT;
  
  UPDATE DW_ORDER_qidian t
  SET FEE_FLAG=0
  WHERE nvl(param_after,param) IN  
        (SELECT nvl(param_after,param)
         FROM DW_ORDER_QIDIAN 
         WHERE user_tag like '%万象用户%'
           AND FEE_FLAG=1
           AND CUSTOMERid='2c91808859631139015a114a430116cb'
           AND ORDER_DATE BETWEEN '20180101' AND '20180131'
        )
    AND user_tag not like '%万象用户%'
    AND FEE_FLAG=1
    AND CUSTOMERid='2c91808859631139015a114a430116cb'
    AND ORDER_DATE BETWEEN '20180101' AND '20180131';
  COMMIT;
  
END P_ETL_XINGYE_201801;
/

