CREATE PROCEDURE P_EMPTY AS 
BEGIN
--在营企业省份空置率
  create table T_EMPTY1 AS
  SELECT 
      T3.CODENAME, SUBSTR(T2.REGORG, 1, 2) || '0000',
       count(t1.input_key),
       SUM(CASE
             WHEN T2.ENTNAME IS NULL THEN
              1
             ELSE
              0
           END) entNAME_NULL,
       SUM(CASE
             WHEN T2.NAME IS NULL THEN
              1
             ELSE
              0
           END) NAME_NULL,
       SUM(CASE
             WHEN T2.OPFROM IS NULL OR T2.OPFROM >= T2.OPTO OR
                  T2.OPFROM > SYSDATE OR
                  TO_CHAR(T2.OPFROM, 'yyyy-mm-dd') = '1900-01-01' THEN
              1
             ELSE
              0
           END) BEGIN_BGF,
       sum(CASE
             WHEN T2.OPto IS NULL OR T2.OPFROM >= T2.OPTO OR
                  TO_CHAR(T2.OPto, 'yyyy-mm-dd') = '1900-01-01' THEN
              1
             ELSE
              0
           END) end_BGF
  from (select distinct input_key, pripid
          from t_order_detail
         where product_tpl_code = '1'
           and id_customer = 'CID_00003985'
           and order_date between '20160902' and '20160908') t1
 INNER JOIN( select * from  ENTERPRISEBASEINFO_0824@NEWDAAS26_DBLINK 
 
    where ENTSTATUS ='1' )t2 ON T1.INPUT_KEY = T2.ENTNAME
    OR T1.INPUT_KEY = T2.REGNO
    OR T1.INPUT_KEY = T2.CREDIT_CODE
    
    
left join(
  SELECT distinct CODENAME ,codevalue
    FROM T_DEX_APP_CODELIST
   WHERE CODE_TYPE_VALUE = 'CA01'
     AND SUBSTR(CODEVALUE, 3, 4) = '0000') T3 ON SUBSTR(T2.REGORG, 1, 2) || '0000' = T3.CODEVALUE
   GROUP BY T3.CODENAME, SUBSTR(T2.REGORG, 1, 2) || '0000';
END P_EMPTY;
/

