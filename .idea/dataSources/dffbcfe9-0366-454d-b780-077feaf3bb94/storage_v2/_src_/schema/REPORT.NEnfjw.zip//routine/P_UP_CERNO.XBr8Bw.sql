CREATE PROCEDURE P_UP_CERNO AS 
BEGIN
update ENTBASEINFO SET CERNO='' where (regexp_like(cerno,'([0-9]|[x]|[X]){18}$'));
COMMIT;
END P_UP_CERNO;
/

