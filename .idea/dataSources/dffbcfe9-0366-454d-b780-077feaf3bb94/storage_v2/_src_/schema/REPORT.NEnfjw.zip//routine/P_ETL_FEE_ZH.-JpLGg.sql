CREATE PROCEDURE P_ETL_FEE_ZH (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  CNT NUMBER;
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_zh
--PURPOSE: 招行订单分析
--CREATOR： 夏培娟
--DATE:    2017-01-17
-------------------------------------------------------------
PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  /**UPDATE T_ORDER_ZH
  SET FEE_FLAG_INPUT3=FEE_FLAG_INPUT,FEE_FLAG_INPUT6=FEE_FLAG_INPUT,FEE_FLAG_INPUT9=FEE_FLAG_INPUT,
    FEE_FLAG_INPUT12=FEE_FLAG_INPUT
  WHERE ORDER_DATE =V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_ZH','给不同时间范围去重标志赋值，给'||V_DATE||'赋值结束');**/
  --三个月内去重
  UPDATE T_ORDER_ZH T
  SET FEE_FLAG_INPUT3=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM T_ORDER_ZH
     WHERE state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN to_char(add_months(to_date(order_date,'yyyymmdd'),-2),'yyyymm')||'01' AND V_DATE --一个月去重
    group by INPUT_KEY
    )
    AND state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理三个月内去重，'||V_DATE||'的订单结束');
  
  --六个月内去重
  UPDATE T_ORDER_ZH T
  SET FEE_FLAG_INPUT6=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM T_ORDER_ZH
     WHERE state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN to_char(add_months(to_date(order_date,'yyyymmdd'),-5),'yyyymm')||'01' AND V_DATE --一个月去重
    group by INPUT_KEY
    )
    AND state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理六个月内去重，'||V_DATE||'的订单结束');
  
  --九个月内去重
  UPDATE T_ORDER_ZH T
  SET FEE_FLAG_INPUT9=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM T_ORDER_ZH
     WHERE  state in ('1','-3') --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN to_char(add_months(to_date(order_date,'yyyymmdd'),-8),'yyyymm')||'01' AND V_DATE --一个月去重
    group by INPUT_KEY
    )
    AND state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理九个月内去重，'||V_DATE||'的订单结束');
  
  --12个月内去重
  UPDATE T_ORDER_ZH T
  SET FEE_FLAG_INPUT12=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM T_ORDER_ZH
     WHERE state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN to_char(add_months(to_date(order_date,'yyyymmdd'),-11),'yyyymm')||'01' AND V_DATE --一个月去重
    group by INPUT_KEY
    )
    AND state in ('1','-3')  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理12个月内去重，'||V_DATE||'的订单结束');
  
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理'||V_DATE||'的订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_ZH','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');
END P_ETL_FEE_ZH;
/

