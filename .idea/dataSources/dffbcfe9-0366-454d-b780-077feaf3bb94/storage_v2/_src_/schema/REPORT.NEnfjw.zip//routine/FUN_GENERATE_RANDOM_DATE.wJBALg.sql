CREATE FUNCTION FUN_GENERATE_RANDOM_DATE 
(
  START_DATE IN DATE 
, END_DATE IN DATE 
) RETURN VARCHAR2 IS 
 rd date;
 r varchar(32) ; --随机日期
 type v_ar is table of varchar2(30);   
 my_ar v_ar:=v_ar('2017-07-03','2017-10-02','2017-10-03','2017-10-04','2017-10-05','2017-10-06','2017-10-07');   
BEGIN
    <<do>>
    SELECT to_date(TRUNC(DBMS_RANDOM.VALUE(
       to_number(to_char(START_DATE,'J')),
       to_number(to_char(END_DATE,'J')))),'J')+
--       DBMS_RANDOM.VALUE(1,3600)/3600 +
       trunc(dbms_random.value(28800,64800)) * 1/24/60/60
       into rd
    FROM dual;
    IF to_char(rd,'yyyy-MM-dd') member of my_ar THEN
      goto do;
    END IF;
    r := concat (to_char(rd,'yyyy-MM-dd HH24:mi:ss'),'.'||trunc(DBMS_RANDOM.VALUE(1,600))||'000');
  RETURN r;
END FUN_GENERATE_RANDOM_DATE;
/

