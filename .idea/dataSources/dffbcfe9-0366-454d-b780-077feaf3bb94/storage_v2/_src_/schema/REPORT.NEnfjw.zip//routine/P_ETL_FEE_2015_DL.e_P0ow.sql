CREATE PROCEDURE P_ETL_FEE_2015_DL (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  CNT NUMBER;
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_2015
--PURPOSE: 处理2015年的计费标志
--CREATOR： 夏培娟
--DATE:    2017-12-27
-------------------------------------------------------------
  PRO_LOG('P_ETL_FEE_2015_DL','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的道隆订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  ---删除vip客户的监控订单,前期用中数智汇，后边用虚拟公司“中数智汇业务监控”，并且不用区分客户----
  DELETE FROM DW_ORDER_DETAIL_DL
  WHERE INPUT_KEY='北京中数智汇科技股份有限公司'
    AND PRODUCT_TPL_CODE='1' --基本查询订单
    AND ORDER_DATE=V_DATE;
  COMMIT; 
  
  DELETE FROM DW_ORDER_DETAIL_DL
  WHERE INPUT_KEY='中数智汇业务监控'
    AND PRODUCT_TPL_CODE='1' --基本查询订单
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  -------首先处理state=-3时候的订单----------
  UPDATE DW_ORDER_DETAIL_DL
  SET RS_KEY=NULL,STATE_ORI='-3',STATE='-1',FEE_FLAG_INPUT=0,FEE_FLAG_RS=0 --将state置为-1，方便后续查询失败订单，同时STATE_ORI保留原始state状态信息
  WHERE (RS_KEY IS NULL OR RS_KEY=',') --失败订单，因为查询结果为空
    AND STATE='-3' --已删除订单
    AND PRODUCT_TPL_CODE IN ('1','10','11','12') --基本查询订单
    AND ORDER_DATE=V_DATE;
  COMMIT; 
  ------处理is_free=7的不计费账户订单-----
  UPDATE DW_ORDER_DETAIL_DL
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE IS_FREE='7' --不计费
    AND ORDER_DATE=V_DATE;
  COMMIT;
 
  
  -------------处理FEE_FLAG_INPUT 按查询关键字去重---------------------------------
  -----------2.1、一般客户的去重规则：当月、按客户去重-------------------
  UPDATE DW_ORDER_DETAIL_DL t
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM DW_ORDER_DETAIL_DL
     WHERE PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --一个月去重
    group by INPUT_KEY,ID_CUSTOMER,KEY_TYPE2
    )
    AND PRODUCT_TPL_CODE IN ('1','10','11','12')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_2015_DL','按照计费去重规则处理是否计费标志，处理'||V_DATE||'的订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_2015_DL','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');


END P_ETL_FEE_2015_DL;
/

