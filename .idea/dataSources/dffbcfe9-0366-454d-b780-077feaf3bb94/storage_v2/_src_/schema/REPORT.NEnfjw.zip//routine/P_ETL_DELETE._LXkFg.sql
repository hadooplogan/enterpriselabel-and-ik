CREATE PROCEDURE P_ETL_DELETE (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(10);
V_DATE1 VARCHAR2(10);
I NUMBER;
CNT NUMBER;
-------------------------------------------------------------
--NAME:    P_ETL_DELETE
--PURPOSE: 数据删除
--CREATOR： 夏培娟
--DATE:    2016-12-07
-------------------------------------------------------------
BEGIN
  PRO_LOG('P_ETL_DELETE','删除hadoop订单明细开始');
  
  
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  V_DATE1:=V_DATE||'%';
  ---统计当天数据量
  SELECT COUNT(ORDERNO) INTO CNT FROM DW_ENTBASEINFO WHERE ORDERNO LIKE V_DATE1  ;
  FOR I IN 1..TRUNC(CNT/1000)+1 LOOP
  EXECUTE IMMEDIATE 'DELETE FROM dw_entbaseinfo  where ROWNUM<=''1000''   AND  ORDERno like '''||V_DATE1||'''';
  COMMIT;
  --PRO_LOG('P_ETL_DELETE','删除'||V_DATE||'hadoop订单明细结束');
  END LOOP;

  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除'||V_DATE||'hadoop订单明细结束');
  V_DATE:=substr(TO_CHAR(TO_DATE('20'||V_DATE,'yyyy-mm-dd')+1,'yyyymmdd'),3,6);
  END LOOP;
  PRO_LOG('P_ETL_DELETE','删除hadoop订单明细结束');
  
  /**PRO_LOG('P_ETL_DELETE','删除hadoop订单明细开始');
  
  ---统计当天数据量
  SELECT COUNT(ORDERNO) INTO CNT FROM DW_ENTBASEINFO WHERE ORDERNO LIKE '160103%'  ;
  FOR I IN 1..TRUNC(CNT/1000)+1 LOOP
  EXECUTE IMMEDIATE 'DELETE FROM dw_entbaseinfo  where ROWNUM<=''1000''   AND  ORDERno like ''160103%'' ';
  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除'||V_DATE||'hadoop订单明细结束');
  END LOOP;

  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除hadoop订单明细结束');**/
  
  /**PRO_LOG('P_ETL_DELETE','删除DW_ORDER_3阿里的日志开始');
  ---统计当天数据量
  SELECT COUNT(*) INTO CNT 
  FROM DW_ORDER_3 
  WHERE CUSTOMERID='ff80808156e456ec0156e458cdec0000' 
  AND STARTTIME BETWEEN TO_DATE('2017-09-01 00:00:00','yyyy-mm-dd hh24:mi:ss')
    and TO_DATE('2017-09-03 23:59:59','yyyy-mm-dd hh24:mi:ss');
  FOR I IN 1..TRUNC(CNT/1000)+1 LOOP
  DELETE FROM DW_ORDER_3  
  WHERE ROWNUM<='1000'   
  AND CUSTOMERID='ff80808156e456ec0156e458cdec0000'
  AND STARTTIME BETWEEN TO_DATE('2017-09-01 00:00:00','yyyy-mm-dd hh24:mi:ss')
    and TO_DATE('2017-09-01 23:59:59','yyyy-mm-dd hh24:mi:ss');
  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除DW_ORDER_3,1000行结束');
  END LOOP;
  
  COMMIT;
PRO_LOG('P_ETL_DELETE','删除DW_ORDER_3阿里的日志结束');
**/

  /**--删除dw_order_qidian的订单量
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  SELECT COUNT(ORDER_NO) INTO CNT 
  FROM DW_ORDER_QIDIAN 
  WHERE CUSTOMERID='ff80808156e456ec0156e458cdec0000'
    AND ORDER_DATE=V_DATE  ;
  FOR I IN 1..TRUNC(CNT/1000)+1 LOOP
  DELETE FROM DW_ORDER_QIDIAN  WHERE ROWNUM<='1000'  AND CUSTOMERID='FF80808156E456EC0156E458CDEC0000' AND  ORDER_DATE=V_DATE;
  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除'||V_DATE||'DW_order_qidian的阿里订单明细结束');
  V_DATE:=to_char(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END LOOP;
  end loop;
  COMMIT;
  PRO_LOG('P_ETL_DELETE','删除日志结束');**/

END P_ETL_DELETE;
/

