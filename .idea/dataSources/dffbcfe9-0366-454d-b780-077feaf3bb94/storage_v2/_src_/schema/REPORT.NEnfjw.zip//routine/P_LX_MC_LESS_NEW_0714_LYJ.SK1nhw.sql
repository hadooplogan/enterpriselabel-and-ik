CREATE PROCEDURE P_LX_MC_LESS_NEW_0714_LYJ AS 
BEGIN
insert into LX_mc_LESS_result_0714_LYJ 
select b.* from LX_MC_LESS_0714_LYJ a
inner join ENTERPRISEBASEINFO_0714@NEWDAAS26_DBLINK  b on a.entname=b.entname and a.s_ext_nodenum=b.s_ext_nodenum;
commit;
END P_LX_MC_LESS_NEW_0714_LYJ;
/

