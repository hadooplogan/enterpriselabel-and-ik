CREATE PROCEDURE P_ETL_FEE_JIANAHNG1512 (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
  V_DATE VARCHAR2(8);
  CNT NUMBER;
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_JIANAHNG1512
--PURPOSE: 建行201512订单计费情况统计
--CREATOR： 夏培娟
--DATE:    2016-09-13
-------------------------------------------------------------
  UPDATE T_jianhang_1512
  SET FEE_FLAG_INPUT='1'
  WHERE PRODUCT_TPL_CODE IN ('1','10')
  and state in ('1','-3');  
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_JIANAHNG1512','将建行成功的基本查询计费标志记为1完成');
  
  PRO_LOG('P_ETL_FEE_JIANAHNG1512','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  
  -------------处理FEE_FLAG_INPUT 按查询关键字去重---------------------------------
  -----------2.1、一般客户的去重规则：当月、按客户去重-------------------
  UPDATE T_jianhang_1512 t
  SET FEE_FLAG_INPUT=0
  WHERE ORDER_NO NOT IN 
    (SELECT MIN(ORDER_NO) 
     FROM T_jianhang_1512
     WHERE PRODUCT_TPL_CODE IN ('1','10')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --一个月去重
    group by INPUT_KEY
    )
    AND PRODUCT_TPL_CODE IN ('1','10')--目前只有工商企业基本信息查询、按个人标识产品计费时去重
    AND FEE_FLAG_INPUT='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_JIANAHNG1512','按照计费去重规则处理是否计费标志，处理'||V_DATE||'的订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_JIANAHNG1512','按照计费去重规则处理是否计费标志，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');
END P_ETL_FEE_JIANAHNG1512;
/

