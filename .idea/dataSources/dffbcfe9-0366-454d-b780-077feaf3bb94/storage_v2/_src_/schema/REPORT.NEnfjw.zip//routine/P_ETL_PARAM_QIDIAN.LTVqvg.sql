CREATE PROCEDURE P_ETL_PARAM_QIDIAN (V_BEGIN VARCHAR2,V_END VARCHAR2) AS 
V_DATE VARCHAR2(8);
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_PARAM_QIDIAN
--PURPOSE: 处理4.0平台的查询参数
--CREATOR： 夏培娟
--DATE:    2018-04-09
-------------------------------------------------------------
  PRO_LOG('P_ETL_PARAM_QIDIAN','处理'||V_BEGIN||'到'||V_END||'拆分查询参数开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
-------华融资产，优先计费企业查询，如果查询对象在企业查询中计费，其他产品的查询不再计费。查分各种查询的查询对象---
  --企业工商信息查询 
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=
    (CASE WHEN SUBSTR(PARAM,10,INSTR(PARAM,'"creditcode":')-11) NOT IN ('null','""') THEN SUBSTR(PARAM,10,INSTR(PARAM,'"creditcode":')-11)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"creditcode":')+13,INSTR(PARAM,'"enttype":')-INSTR(PARAM,'"creditcode":')-14) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"creditcode":')+13,INSTR(PARAM,'"enttype":')-INSTR(PARAM,'"creditcode":')-14)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"name":')+7,INSTR(PARAM,'"id":')-INSTR(PARAM,'"name":')-8) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"name":')+7,INSTR(PARAM,'"id":')-INSTR(PARAM,'"name":')-8)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"id":')+5,INSTR(PARAM,'"version":')-INSTR(PARAM,'"id":')-6) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"id":')+5,INSTR(PARAM,'"version":')-INSTR(PARAM,'"id":')-6)
     else param  end)
  WHERE PRODUCTCODE='enterprise-datasource'
    AND CUSTOMERID='2c9180c25dea8e29015e37e2135c7e56'
    AND ORDER_DATE =V_DATE;
  COMMIT;
  
  --关联洞察 控制路径异步和族谱异步
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=
    (CASE WHEN SUBSTR(PARAM,12,INSTR(PARAM,'","')-11) NOT IN ('null','""') THEN SUBSTR(PARAM,12,INSTR(PARAM,'","')-11)
     ELSE PARAM END )
  WHERE PRODUCTCODE='relations'
    AND CUSTOMERID='2c9180c25dea8e29015e37e2135c7e56'
    AND ORDER_DATE =V_DATE;
  COMMIT;
  
  --经营及违法 拆分entName和id
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=
    (CASE WHEN SUBSTR(SUBSTR(PARAM,INSTR(PARAM,'"entName":')),11,INSTR(SUBSTR(PARAM,INSTR(PARAM,'"entName":')),'","')-10) NOT IN ('null','""')  THEN SUBSTR(SUBSTR(PARAM,INSTR(PARAM,'"entName":')),11,INSTR(SUBSTR(PARAM,INSTR(PARAM,'"entName":')),'","')-10)
       WHEN INSTR(PARAM,'"id":')<>0 AND SUBSTR(REPLACE(PARAM,'|0',''),7,LENGTH(REPLACE(PARAM,'|0',''))-7) NOT IN ('null','""')  THEN SUBSTR(REPLACE(PARAM,'|0',''),7,LENGTH(REPLACE(PARAM,'|0',''))-7)
     ELSE PARAM END)
  WHERE PRODUCTCODE ='geniusty'
    AND CUSTOMERID='2c9180c25dea8e29015e37e2135c7e56'
    and order_date =V_DATE;
  COMMIT;

  --组织机构信息查询
    UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=
    (CASE WHEN SUBSTR(PARAM,10,INSTR(PARAM,'"creditcode":')-11) NOT IN ('null','""') THEN SUBSTR(PARAM,10,INSTR(PARAM,'"creditcode":')-11)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"creditcode":')+13,INSTR(PARAM,'"orgcode":')-INSTR(PARAM,'"creditcode":')-14) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"creditcode":')+13,INSTR(PARAM,'"orgcode":')-INSTR(PARAM,'"creditcode":')-14)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"orgcode":')+10,INSTR(PARAM,'"name":')-INSTR(PARAM,'"orgcode":')-11) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"orgcode":')+10,INSTR(PARAM,'"name":')-INSTR(PARAM,'"orgcode":')-11)
       WHEN SUBSTR(PARAM,INSTR(PARAM,'"name":')+7,LENGTH(PARAM)-INSTR(PARAM,'"name":')-7) NOT IN ('null','""') THEN SUBSTR(PARAM,INSTR(PARAM,'"name":')+7,LENGTH(PARAM)-INSTR(PARAM,'"name":')-7)
    ELSE PARAM END )
  WHERE PRODUCTCODE IN ('org-datasource')
    AND CUSTOMERID='2c9180c25dea8e29015e37e2135c7e56'
    and order_date =V_DATE;
  COMMIT;
  END;
  
  PRO_LOG('P_ETL_PARAM_QIDIAN','处理'||V_DATE||'拆分查询参数结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');

  END LOOP;
  
END P_ETL_PARAM_QIDIAN;
/

