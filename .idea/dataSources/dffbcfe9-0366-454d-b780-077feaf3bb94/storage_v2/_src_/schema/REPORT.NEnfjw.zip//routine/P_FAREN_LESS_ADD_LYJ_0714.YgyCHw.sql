CREATE PROCEDURE P_FAREN_LESS_ADD_LYJ_0714 AS 
BEGIN
  INSERT INTO FAREN_LESS_ADD_LYJ_0714
select case ent.entstatus
when '1' then '在营'
when '2' then '吊销'
when '3' then '注销'
when '4' then '迁出'
when '8' then '停业'
when '9' then '其他' 
else ent.entstatus END,count(distinct ent.pripid)  
from ENTERPRISEBASEINFO_0714@NEWDAAS26_DBLINK ent
left join e_pri_person_0714@NEWDAAS26_DBLINK ep on ep.s_ext_nodenum=ent.s_ext_nodenum and ep.pripid=ent.pripid and ep.Lerepsign='1'
left join st_qggs.F_QGGS_JBXX_BAK20160516@LX210_DBLINK eplx on eplx.nodenum=ent.s_ext_nodenum and eplx.zch=ent.regno and eplx.mc=ent.entname
where  (ep.pripid is null or ep.name is null) and eplx.fddbr is not null
group by ent.entstatus;
COMMIT;
END P_FAREN_LESS_ADD_LYJ_0714;
/

