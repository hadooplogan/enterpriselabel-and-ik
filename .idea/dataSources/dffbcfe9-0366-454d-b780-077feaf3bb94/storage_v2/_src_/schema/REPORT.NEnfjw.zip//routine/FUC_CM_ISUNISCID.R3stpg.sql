CREATE FUNCTION FUC_CM_ISUNISCID (
  v_UNISCID in varchar2
)
RETURN INT
---------------------------------------------------------------------------
  -- 函数名称: FUC_CM_ISUNISCID
  -- 责 任 人: wgz
  -- 功能描述: 验证是否为有效的 统一社会信用代码
  --           返回值：0 为有效 ，1 为无效
  -- 版 本 号: v1.0.0
  -- 备    注:
  -- 修改历史:
  --
  -- 版本: wgz 2017-06-11
  -- 版权: 中数智汇
---------------------------------------------------------------------------
IS --/* 变量声明 */
  CHK_RSL    INT DEFAULT 1; -- 默认状态为 无效--
  I INTEGER  DEFAULT 0;     ---循环变量
  V1         VARCHAR2(1) ;  -- 临时变量 存放信用代码的每个字符值
  V2         VARCHAR2(1) ;  -- 校验位X 
  V_NUM      INT DEFAULT 0; -- 临时变量 
  V_ROWNUM   INT DEFAULT 0;
BEGIN
  --/* 函数主体 */

  -- 如果注册号位数不为18位，则直接返回1 
  IF( LENGTH(v_UNISCID) <> 18 or v_UNISCID is null) THEN 
     RETURN 1;
  END IF ;

  -- 如果区域代码（第3/4位为省）不是合法的，则直接返回
  IF( substr(v_UNISCID,3,2) not in ( '10','11','12','13','14','15','21','22','23','31','32','33','34','35','36','37','41','42','43','44','45','46','50','51','52','53','54','61','62','63','64','65'))
    THEN RETURN 1 ;
  END IF ;


  --- 数值检验
  IF ( replace(translate(v_UNISCID,'0123456789ABCDEFGHJKLMNPQRTUWXY','@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'),'@','') is not null ) THEN  
    RETURN 1; 
  END IF;


  --- 校验位X处理
  -- 1 <= I <= 17时 
  I := 1;
  WHILE I < LENGTH(v_UNISCID) LOOP 
     V1 := substr(v_UNISCID, I, 1);
     select t.row_num into V_ROWNUM from (select rownum-1 row_num,substr('0123456789ABCDEFGHJKLMNPQRTUWXY',rownum,1) as c_str from dual connect by rownum <= length('0123456789ABCDEFGHJKLMNPQRTUWXY')) t where t.c_str = V1;
     V_NUM := V_NUM + mod(power(3,I-1),31) * V_ROWNUM; 
     I := I + 1;
  END LOOP; 
  V_NUM := 31 - mod(V_NUM, 31);
  -- 校验码 
  IF ( V_NUM = 31 ) THEN 
    V2 := '0';
  ELSE 
    select t.c_str into V2 from (select rownum-1 row_num,substr('0123456789ABCDEFGHJKLMNPQRTUWXY',rownum,1) as c_str from dual connect by rownum <= length('0123456789ABCDEFGHJKLMNPQRTUWXY')) t where t.row_num = V_NUM;
  END IF;
  ---是否合规 
  IF ( V2 <> substr(v_UNISCID,18,1) ) THEN 
    RETURN 1; 
  END IF;

  CHK_RSL := 0; 
  RETURN CHK_RSL;

EXCEPTION
  when others then
  return 1;
END FUC_CM_ISUNISCID;
/

