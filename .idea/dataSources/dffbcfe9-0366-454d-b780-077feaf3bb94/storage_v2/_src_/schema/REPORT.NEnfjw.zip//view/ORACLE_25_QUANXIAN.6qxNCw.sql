CREATE VIEW ORACLE_25_QUANXIAN AS
  SELECT T1.ID 客户ID,T1.BRIEF_NAME 客户简称,T1.FULL_NAME 客户全称,T1.STATE 客户状态, T2.ID 用户ID,
   T2.USER_NAME 用户名,T2.STATE 用户状态,T3.U_ID 用户UID,T3.UKEY_NO 用户UKEY编号,T4.CODE_PRODUCT_TPL 产品编码,
   T5.PRODUCT_TPL_NAME 产品名称,T4.ID_PRODUCT_ORDER_TPL 权限模板编码,T6.ID_PRODUCT_ORDER 菜单编码,
   T6.ID_COLUMN 列编码,T7.CODE_COLUMN_GROUP 模块编码,T7.NODE_NAME 列名称,T7.COL_DESC 列描述,
   T8.COLUMN_GROUP_NAME 模块名称,T8.FUNC_CODE,
 t3.is_free is_free_code,
 case t3.is_free when '1' then '正式-收工本费' when '2' then '正式-免工本费' when '3' then '正式-专线虚拟' when '4' then '试用-专线虚拟' when '5' then '试用-外网虚拟' when '6' then '自服务-虚拟' when '7' then '不计费' when '8' then '免ukey虚拟' when '9' then '互联网接口' end  is_free_name,
t9.user_name saler 
 FROM T_CUSTOMER@daas T1 --客户表
 LEFT JOIN T_USER@daas T2 ON T1.ID=T2.ID_CUSTOMER --用户表
 LEFT JOIN T_UKEY@daas T3 ON T2.ID=T3.ID_USER_USE --ukey表
 LEFT JOIN T_PRODUCT_ORDER@daas T4 ON T2.ID_PRODUCT_ORDER_TPL=T4.ID_PRODUCT_ORDER_TPL
 left join t_product_tpl@daas t5 on t4.CODE_PRODUCT_TPL=t5.code
 LEFT JOIN T_PRODUCT_ORDER_COL@daas T6 ON T6.ID_PRODUCT_ORDER=T4.ID
 LEFT JOIN T_COLUMN@daas T7 ON T6.ID_COLUMN=T7.ID
 left join T_COLUMN_GROUP@daas t8 on t7.code_column_group=t8.code
LEFT JOIN GSINFO.T_USER@DAAS T9 ON T1.ID_SALE_MANAGER=T9.ID
/

