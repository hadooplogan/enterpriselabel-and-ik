CREATE PROCEDURE PROC_ORDER_3 AS 
BEGIN
  insert into dw_order_3_UNION
select 
id,userid,username,customerid,customerfullname,productcode,productname,functioncode,functionname,
starttime,finishtime,executetime,result,param,ip,agent,enterprisename,industry,registeredcapital,establisheddate,area,thirdid,logtimestamp,uuid
from dw_order_3_201611;
COMMIT;
END PROC_ORDER_3;
/

