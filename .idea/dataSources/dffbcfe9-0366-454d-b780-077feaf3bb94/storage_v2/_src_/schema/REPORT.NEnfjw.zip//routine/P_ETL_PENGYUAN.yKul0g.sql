CREATE PROCEDURE P_ETL_PENGYUAN (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(10);
-------------------------------------------------------------
--NAME:    P_ETL_PENGYUAN
--PURPOSE: 统计鹏元数据
--CREATOR： 夏培娟
--DATE:    2017-12-20
-------------------------------------------------------------
BEGIN
PRO_LOG('P_ETL_PENGYUAN','抽取'||V_BEGIN||'到'||V_END||'鹏元统计数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  insert into dm_pengyuan
SELECT PRODUCT_TPL_name productname,
case when SUBSTR(ORDER_TYPE,0,35) in ('10000000000000010000000000000000100','10000000000000010000000000010000100','00001') then '企业照面'
        when SUBSTR(ORDER_TYPE,0,35) in( '11010000000000010000000000000000100''11010000000000010000000000010000100') then '照面股东人员'
        when SUBSTR(ORDER_TYPE,0,35) in( '11010001110000010000000000000000100','11010001110000010000000000010000100') then'投资任职'
        when SUBSTR(ORDER_TYPE,0,35) in( '00000000001110000000000000010000000'） then '籍贯'
        when SUBSTR(ORDER_TYPE,0,35) in( '00000000001110000000000000000000000') then  '个人标示'
        when PRODUCT_TPL_CODE IN ('9') and key_type='12' then '人员核验'
        else key_type||','||order_type end  functionname,
order_date,u_id,user_name,count(order_no) cn_vol
     FROM DW_ORDER_DETAIL
     WHERE ( PRODUCT_TPL_CODE IN ('1','10','11','12') or (PRODUCT_TPL_CODE IN ('9') and key_type='12'))--目前只有工商企业基本信息查询、按个人标识产品计费时去重
       AND ORDER_DATE =V_DATE
       AND ID_CUSTOMER='CID_00000067'
     GROUP BY PRODUCT_TPL_name,
case when SUBSTR(ORDER_TYPE,0,35) in ('10000000000000010000000000000000100','10000000000000010000000000010000100','00001') then '企业照面'
        when SUBSTR(ORDER_TYPE,0,35) in( '11010000000000010000000000000000100''11010000000000010000000000010000100') then '照面股东人员'
        when SUBSTR(ORDER_TYPE,0,35) in( '11010001110000010000000000000000100','11010001110000010000000000010000100') then'投资任职'
        when SUBSTR(ORDER_TYPE,0,35) in( '00000000001110000000000000010000000'） then '籍贯'
        when SUBSTR(ORDER_TYPE,0,35) in( '00000000001110000000000000000000000') then  '个人标示'
        when PRODUCT_TPL_CODE IN ('9') and key_type='12' then '人员核验'
        else key_type||','||order_type end  ,
order_date,u_id,user_name;
commit;
  COMMIT;
  PRO_LOG('P_ETL_PENGYUAN','抽取'||V_DATE||'鹏元统计数据结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
COMMIT;
PRO_LOG('P_ETL_PENGYUAN','抽取'||V_BEGIN||'到'||V_END||'鹏元统计数据结束');
END P_ETL_PENGYUAN;
/

