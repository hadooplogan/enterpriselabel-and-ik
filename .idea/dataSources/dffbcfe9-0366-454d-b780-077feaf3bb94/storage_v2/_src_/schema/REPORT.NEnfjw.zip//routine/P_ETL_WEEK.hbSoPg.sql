CREATE PROCEDURE P_ETL_WEEK (V_BEGIN VARCHAR2,V_END VARCHAR2) AS 
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_WEEK
--PURPOSE: 生成每天是第几周
--CREATOR： 夏培娟
--DATE:    2016-09-07
-------------------------------------------------------------
BEGIN
  PRO_LOG('P_ETL_WEEK','抽取'||V_BEGIN||'到'||V_END||'的星期数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  DELETE FROM DIM_DATE WHERE YYYYMMDD=V_DATE;
    INSERT INTO DIM_DATE
      (YYYYMMDD,
       WEEK,
       YYYY)
    SELECT V_DATE,
      TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd'),'ww'),
      SUBSTR(V_DATE,1,4)
    FROM DUAL;
    COMMIT;
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  UPDATE DIM_DATE T
  SET C_RANGE=(SELECT SUBSTR(MIN(YYYYMMDD),5,4) FROM DIM_DATE WHERE WEEK=T.WEEK)||'至'
              ||(SELECT substr(MAX(YYYYMMDD),5,4) FROM DIM_DATE WHERE WEEK=T.WEEK);
  COMMIT;
  
  PRO_LOG('P_ETL_WEEK','抽取'||V_BEGIN||'到'||V_END||'的星期数据结束');
END P_ETL_WEEK;
/

