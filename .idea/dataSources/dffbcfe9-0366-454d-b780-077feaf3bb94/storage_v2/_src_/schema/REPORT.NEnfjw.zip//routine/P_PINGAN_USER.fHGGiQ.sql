CREATE PROCEDURE P_PINGAN_USER AS 
-------------------------------------------------------------
--NAME:    P_PINGAN_USER
--PURPOSE: 根据4.0平台的数据生成平安银行机构信息
--CREATOR： 夏培娟
--DATE:    2018-04-08
-------------------------------------------------------------
BEGIN
DELETE FROM DIM_USER_PINGAN;
COMMIT;

INSERT INTO DIM_USER_PINGAN
(UKEY_NO,DEP,P_DEP )
SELECT user_name ukey_no,BILL_DEPARTMENT dep,business_DEPARTMENT p_dep
FROM MYSQL_T_USER
WHERE CUSTOMER_ID='2c9180c25dea8e29015e18e34de06260';
COMMIT;

END P_PINGAN_USER;
/

