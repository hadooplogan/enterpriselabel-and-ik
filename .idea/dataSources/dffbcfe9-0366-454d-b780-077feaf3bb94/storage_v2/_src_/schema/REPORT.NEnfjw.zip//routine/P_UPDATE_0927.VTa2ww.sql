CREATE PROCEDURE P_UPDATE_0927 (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_UPDATE_0927
--PURPOSE: update明细表中个人标示查询的输入关键字的回车符
--CREATOR： 夏培娟
--DATE:    2016-09-27
-------------------------------------------------------------
BEGIN
PRO_LOG('P_UPDATE_0927','更新'||V_BEGIN||'到'||V_END||'订单结果信息');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  /**update t_order_detail
  set input_key=replace(input_key,chr(13),''), unique_key=replace(unique_key,chr(13),'')
  where input_key<>input_key_ori
  and key_type='9'
  and order_date=v_date;**/
  update t_order_detail t1
  set (t1.S_EXT_NODENUM,t1.ENTNAME,t1.REGNO,t1.REGCAP,t1.REGCAPCUR,t1.ENTTYPE,t1.ENTSTATUS,t1.INDUSTRYPHYCODE,
  t1.INDUSTRYCOCODE,t1.DOMDISTRICT,t1.ESDATE,t1.PER_NAME,t1.PER_CERNO,t1.SRCTYPE,t1.pripid,t1.PERSON_ID_BOCOM)=
  (select S_EXT_NODENUM,ENTNAME,REGNO,REGCAP,REGCAPCUR,ENTTYPE,ENTSTATUS,INDUSTRYPHYCODE,
    INDUSTRYCOCODE,DOMDISTRICT,ESDATE,PERSIONNAME,CERNO,SRCTYPE,pripid,PERSON_ID_BOCOM
  from entbaseinfo
  where rownum=1
    and orderno=t1.order_no
    and substr(orderno,1,6)= substr(v_date,3,6))
  where product_tpl_code in ('1','10')
    and t1.state in ('1','-3')
    and t1.order_date=v_date;
  commit;
  PRO_LOG('P_UPDATE_0927','更新'||V_DATE||'大部分订单结果信息结束');
  
  update t_order_detail t1
  set unique_key=(case when key_type in ('2','3','5','13') then PRIPID||','||ENTNAME 
                       when key_type in ('4','10')  then PERSON_ID_BOCOM||','||PER_NAME 
                       when key_type ='9'  THEN input_key||','||PER_NAME 
                  else null end)
where  product_tpl_code in ('1','10')
    and t1.state in ('1','-3')
    and t1.order_date=v_date;
  
  commit;
  PRO_LOG('P_UPDATE_0927','更新'||V_DATE||'unique_key信息结束');
  
  COMMIT;
  PRO_LOG('P_UPDATE_0927','更新'||V_DATE||'订单结果信息结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
COMMIT;
PRO_LOG('P_UPDATE_0927','更新'||V_BEGIN||'到'||V_END||'订单结果信息结束');
END P_UPDATE_0927;
/

