CREATE PROCEDURE P_ETL_IS_LEGAL (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
 V_DATE VARCHAR2(8);
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_IS_LEGAL
--PURPOSE: 2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，查询关键字是否合法.0为合法，1为不合法
--CREATOR： 夏培娟
--DATE:    2017-07-05
-------------------------------------------------------------
  
  PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，判断查询关键字是否合法，处理'||V_BEGIN||'到'||V_END||'范围内的订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  ------------------------校验所有订单-----------------------------
  UPDATE DW_ORDER_DETAIL
  SET IS_LEGAL_ALL=FUC_CM_ISREGNO(CASE WHEN DRILL_DOWN=1 THEN SUBSTR(INPUT_KEY,INSTR(INPUT_KEY,'-',1,1)+1,LENGTH(INPUT_KEY)-INSTR(INPUT_KEY,'-',1,1)-1) ELSE INPUT_KEY END) --如果是下探订单，需要把注册号拆分出来
  WHERE PRODUCT_TPL_CODE IN ('1','10','11','12') --基本信息查询
    AND KEY_TYPE='3' --按注册号查询
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按注册号查询时，判断所有订单，查询关键字是否合法，处理'||V_DATE||'的订单结束');
  
  UPDATE DW_ORDER_DETAIL
  SET IS_LEGAL_ALL=FUC_CM_ISUNISCID(INPUT_KEY) --按统一社会信用代码查询时没有下探订单
  --FUC_CM_ISUNISCID(CASE WHEN DRILL_DOWN=1 THEN SUBSTR(INPUT_KEY,INSTR(INPUT_KEY,'-',1,1)+1,LENGTH(INPUT_KEY)-INSTR(INPUT_KEY,'-',1,1)-1) ELSE INPUT_KEY END) --如果是下探订单，需要把统一社会信用代码拆分出来
  WHERE PRODUCT_TPL_CODE IN ('1','10','11','12') --基本信息查询
    AND KEY_TYPE='13' --按统一社会信用代码查询
    AND ORDER_DATE=V_DATE;
  COMMIT;
  --PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按统一社会信用代码查询时，判断所有订单，查询关键字是否合法，处理'||V_DATE||'的订单结束');
  
  UPDATE DW_ORDER_DETAIL
  SET IS_LEGAL_ALL='null' --为方便查询名字，将未判断的置为‘null’
  --FUC_CM_ISUNISCID(CASE WHEN DRILL_DOWN=1 THEN SUBSTR(INPUT_KEY,INSTR(INPUT_KEY,'-',1,1)+1,LENGTH(INPUT_KEY)-INSTR(INPUT_KEY,'-',1,1)-1) ELSE INPUT_KEY END) --如果是下探订单，需要把统一社会信用代码拆分出来
  WHERE PRODUCT_TPL_CODE IN ('1','10','11','12') --基本信息查询
    AND KEY_TYPE in ('2','5') --按企业名称和组织机构代码查询的关键字，合法性暂不判断（建行没有组代查询）
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，判断查询关键字是否合法，处理'||V_DATE||'的订单结束');
  
  -------------------------生成统计表-----------------
  DELETE FROM DM_ENT_LEGAL_DAILY WHERE C_DATE=V_DATE;
  COMMIT;
  
  INSERT INTO DM_ENT_LEGAL_DAILY
    (C_DATE,
    ID_CUSTOMER,
    FULL_NAME,
    U_ID,
    UKEY_NO,
    USER_NAME,
    REGNO_VOL,
    REGNO_FOUND,
    REGNO_SUCCESS_NOT_LEGAL,
    REGNO_FAIL_NOT_LEGAL,
    CREDIT_VOL,
    CREDIT_FOUND,
    CREDIT_SUCCESS_NOT_LEGAL,
    CREDIT_FAIL_NOT_LEGAL,
    ENTNAME_VOL,
    ENTNAME_FOUND,
    ORGCODE_VOL,
    ORGCODE_FOUND)
  SELECT T1.ORDER_DATE,
    T1.ID_CUSTOMER ,
    T2.FULL_NAME,
    T1.U_ID,
    T1.UKEY_NO,
    T1.USER_NAME,
    SUM(CASE WHEN T1.KEY_TYPE='3' THEN 1 ELSE 0 END) REGNO_VOL,--注册号查询量
    SUM(CASE WHEN T1.KEY_TYPE='3' AND T1.STATE IN ('1','-3') THEN 1 ELSE 0 END ) REGNO_FOUND,--注册号查得量
    SUM(CASE WHEN T1.KEY_TYPE='3' AND T1.STATE IN ('1','3') AND T1.IS_LEGAL_ALL='1' THEN 1 ELSE 0 END) REGNO_SUCCESS_NOT_LEGAL ,--注册号查询，成功订单，查询关键字非法
    SUM(CASE WHEN T1.KEY_TYPE='3' AND T1.STATE NOT IN ('1','3') AND T1.IS_LEGAL_ALL='1'  THEN 1 ELSE 0 END) REGNO_FAIL_NOT_LEGAL,--注册号查询，失败订单，查询关键字非法
    SUM(CASE WHEN T1.KEY_TYPE='13' THEN 1 ELSE 0 END) CREDIT_VOL,--统一社会信用代码查询量
    SUM(CASE WHEN T1.KEY_TYPE='13' AND T1.STATE IN ('1','-3') THEN 1 ELSE 0 END ) CREDIT_FOUND,--统一社会信用代码查得量
    SUM(CASE WHEN T1.KEY_TYPE='13' AND T1.STATE IN ('1','3') AND T1.IS_LEGAL_ALL='1' THEN 1 ELSE 0 END) CREDIT_SUCCESS_NOT_LEGAL ,--统一社会信用代码查询，成功订单，查询关键字非法
    SUM(CASE WHEN T1.KEY_TYPE='13' AND T1.STATE NOT IN ('1','3') AND T1.IS_LEGAL_ALL='1'  THEN 1 ELSE 0 END) CREDIT_FAIL_NOT_LEGAL,--统一社会信用代码查询，失败订单，查询关键字非法
    SUM(CASE WHEN T1.KEY_TYPE='2' THEN 1 ELSE 0 END) ENTNAME_VOL,--企业名称查询量
    SUM(CASE WHEN T1.KEY_TYPE='2' AND T1.STATE IN ('1','-3') THEN 1 ELSE 0 END ) ENTNAME_FOUND,--企业名称查得量
    SUM(CASE WHEN T1.KEY_TYPE='5' THEN 1 ELSE 0 END) ORGCODE_VOL,--组织机构代码查询量
    SUM(CASE WHEN T1.KEY_TYPE='5' AND T1.STATE IN ('1','-3') THEN 1 ELSE 0 END ) ORGCODE_FOUND --组织机构代码查得量
  FROM DW_ORDER_DETAIL T1
  LEFT JOIN DIM_CUSTOMER T2 ON T1.ID_CUSTOMER=T2.ID_CUSTOMER   
  WHERE ORDER_DATE =V_DATE
    AND PRODUCT_TPL_CODE IN ('1','10','11','12') --基本信息查询
    AND KEY_TYPE IN ('3','13','2','5')
  GROUP BY T1.ORDER_DATE,T1.ID_CUSTOMER ,T2.FULL_NAME,T1.U_ID,T1.UKEY_NO,T1.USER_NAME,T1.KEY_TYPE;
  COMMIT;
  PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，判断查询关键字是否合法，生成'||V_DATE||'的统计数据');

  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_IS_LEGAL','2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，查询关键字是否合法，处理'||V_BEGIN||'到'||V_END||'范围内的订单结束');

END P_ETL_IS_LEGAL;
/

