CREATE PROCEDURE P_ALI_REGNO_ENT_OUTPUT AS 
BEGIN
INSERT INTO ALI_REGNO_ENT_OUTPUT
select distinct ent.regno,ent.credit_code,ent.entname,ent.name,ent.cerno 
from enterprisebaseinfo_0714@NEWDAAS26_DBLINK ent
where regno in
(select regno from ali_regno_input);
COMMIT;
END P_ALI_REGNO_ENT_OUTPUT;
/

