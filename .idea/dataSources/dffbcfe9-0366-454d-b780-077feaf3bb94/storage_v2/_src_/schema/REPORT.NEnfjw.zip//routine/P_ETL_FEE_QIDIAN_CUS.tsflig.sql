CREATE PROCEDURE P_ETL_FEE_QIDIAN_CUS
(V_QIDIAN_BEGIN VARCHAR2,V_QIIDAN_END VARCHAR2,v_customer_3 VARCHAR2) AS
 V_DATE VARCHAR2(8);
BEGIN
-------------------------------------------------------------
--NAME:    P_ETL_FEE_QIDIAN_CUS
--PURPOSE: 3.0平台订单去重计费:每天增量处理计费标志
--CREATOR： 夏培娟
--DATE:    2017-07-31
--美团，企业查询当月去重。
--兴业银行，企业查询和企典，不去重
--remark:  只处理有出账需求的客户数据，因为3.0的参数特别长，并且是接口用户，调用量特别大，如阿里，故为减轻系统负担只对有出账需求的客户去重计费
--客户出账说明：美团从2017-2-24开始正式使用系统，出账；
--上海敬众，数据核验去重，jephy提出的需求
-------------------------------------------------------------
 PRO_LOG('P_ETL_FEE_QIDIAN_CUS','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||','||v_customer_3||'订单的计费标志开始');
  V_DATE:=V_QIDIAN_BEGIN;
  
  WHILE V_DATE<=V_QIIDAN_END LOOP
  BEGIN
  -------------2.1 华融资产 正常去重之后，再跨产品去重------------------
  UPDATE DW_ORDER_QIDIAN T
  SET FEE_FLAG=0
  WHERE nvl(param_after,param)  IN 
    (SELECT nvl(param_after,param)
     FROM DW_ORDER_QIDIAN
     WHERE PRODUCTCODE in ('enterprise-datasource')
       AND FEE_FLAG='1'  --只在查得记录(抽取基础数据时已将查得记录的计费标志记为1)中去重
       AND CUSTOMERID ='2c9180c25dea8e29015e37e2135c7e56' --华融资产跨产品去重
       AND ORDER_DATE BETWEEN SUBSTR(V_DATE,1,6)||'01' AND V_DATE --当月去重
     GROUP BY CUSTOMERID,nvl(param_after,param)
    )
    AND PRODUCTCODE not in ('enterprise-datasource')
    AND FEE_FLAG='1'
    AND CUSTOMERID  ='2c9180c25dea8e29015e37e2135c7e56' --华融资产跨产品去重
    AND ORDER_DATE=V_DATE;
  COMMIT;
  
  PRO_LOG('P_ETL_FEE_QIDIAN_CUS','按照查询参数去重，处理'||V_DATE||','||v_customer_3||'订单的计费标志结束');

  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
  
  PRO_LOG('P_ETL_FEE_QIDIAN_CUS','按照查询参数去重，处理'||V_QIDIAN_BEGIN||'到'||V_QIIDAN_END||','||v_customer_3||'订单的计费标志结束');
  
END P_ETL_FEE_QIDIAN_CUS;
/

