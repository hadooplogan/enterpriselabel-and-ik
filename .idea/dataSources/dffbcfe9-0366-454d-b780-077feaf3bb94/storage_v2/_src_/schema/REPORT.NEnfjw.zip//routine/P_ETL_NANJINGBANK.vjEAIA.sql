CREATE PROCEDURE P_ETL_NANJINGBANK (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(10);
-------------------------------------------------------------
--NAME:    P_ETL_NANJINGBANK
--PURPOSE: 南京银行，风铃变更推送的企业，基本查询不计费
--CREATOR： 夏培娟
--DATE:    2017-09-18
-------------------------------------------------------------
BEGIN
PRO_LOG('P_ETL_NANJINGBANK','处理'||V_BEGIN||'到'||V_END||'南京银行风铃变更推送订单开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  
  UPDATE DW_ORDER_DETAIL
  SET FEE_FLAG_RS=0,FEE_FLAG_INPUT=0
  WHERE KEY_TYPE IN ('2','3','5','13')--企业基本信息查询
    AND INPUT_KEY IN (SELECT ENTNAME FROM NANJING_BANK_FENGLING_201708)
    AND ID_CUSTOMER='CID_00000036'
    AND ORDER_DATE=V_DATE;
    
  COMMIT;
  PRO_LOG('P_ETL_NANJINGBANK','处理'||V_DATE||'南京银行风铃变更推送订单结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;
END P_ETL_NANJINGBANK;
/

