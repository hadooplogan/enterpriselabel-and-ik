CREATE PROCEDURE P_ETL_DATE (V_BEGIN VARCHAR2,V_END VARCHAR2)AS 

V_date VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_DATE
--PURPOSE: 每天向日期表中添加数据
--CREATOR： 夏培娟
--DATE:    2016-11-08
-------------------------------------------------------------
BEGIN
  --V_BEGIN:=TO_CHAR(SYSDATE-1,'yyyymmdd');--'20151201';
  --V_end:=to_char(sysdate-1,'yyyymmdd');
  PRO_LOG('P_ETL_date','抽取'||V_BEGIN||'到'||V_END||'的日期数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP
  BEGIN
  DELETE FROM DIM_DATE WHERE c_date=V_DATE;
    INSERT INTO DIM_DATE
      (C_DATE,
      C_MONTH,
      C_MONTH_CHN,
      YEAR_CHN,
      DATE_CHN,
      MONTH_CHN)
    SELECT V_DATE,
      SUBSTR(V_DATE,1,6),
      SUBSTR(V_DATE,1,4)||'年'||CASE WHEN SUBSTR(V_DATE,5,1)='0' THEN SUBSTR(V_DATE,6,1) ELSE SUBSTR(V_DATE,5,2) END ||'月份对账单',
      SUBSTR(V_DATE,1,4)||'年',
      SUBSTR(V_DATE,1,4)||'年'||CASE WHEN SUBSTR(V_DATE,5,1)='0' THEN SUBSTR(V_DATE,6,1) ELSE SUBSTR(V_DATE,5,2) END ||'月'||CASE WHEN SUBSTR(V_DATE,7,1)='0' THEN SUBSTR(V_DATE,8,1) ELSE SUBSTR(V_DATE,7,2) END||'日',
      CASE WHEN SUBSTR(V_DATE,5,1)='0' THEN SUBSTR(V_DATE,6,1) ELSE SUBSTR(V_DATE,5,2) END ||'月' 
    FROM DUAL;
    COMMIT;
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
  END;
  END LOOP;

  COMMIT;
  
  PRO_LOG('P_ETL_date','抽取'||V_BEGIN||'到'||V_END||'的日期数据结束');
END P_ETL_DATE;
/

