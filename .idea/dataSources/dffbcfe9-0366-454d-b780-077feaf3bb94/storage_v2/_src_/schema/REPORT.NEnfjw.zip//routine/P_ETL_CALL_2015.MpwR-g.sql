CREATE PROCEDURE P_ETL_CALL_2015 (V_BEGIN VARCHAR2,V_END VARCHAR2,IS_RUN_MONTH VARCHAR2,V_MONTH VARCHAR2,V_CONTRACT VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    P_ETL_CALL_2015
--PURPOSE: 处理2015年的数据
--CREATOR： 夏培娟
--DATE:    2017-12-27
--PARAM:   V_BEGIN:前一天时间，格式YYYYMMDD ；
--         V_END:前一天时间，格式YYYYMMDD；
--         IS_RUN_MONTH:Y/N,每月1号时标志为Y；
--         V_MONTH:IS_RUN_MONTH='Y'时，此参数有用，处理上月数据，格式YYYYMM;
--         V_CONTRACT:IS_RUN_MONTH='Y'时，此参数有用,生成账单中的账期，当月的账期，不是上个月的账期；
-------------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DATE('''||V_BEGIN||''','''||V_END||'''); END;';   --时间维表插入数据，默认插入执行程序当天的时间
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_INSERT_CUS;END;';   --更新客户维表，没有时间参数，存储过程内部取系统时间，记录更改记录的时间
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_CONTRACT_QIDIAN; END;';--生成企典的合同信息
  EXECUTE IMMEDIATE 'BEGIN P_ETL_FEE_2015('''||V_BEGIN||''','''||V_END||'''); END;';--处理计费标志
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_RELATIONS_PARAM('''||V_BEGIN||''','''||V_END||'''); END;'; --处理安徽智侒信和亚联数据多节点关联关系去重
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_FEE_QIDIAN('''||V_BEGIN||''','''||V_END||'''); END;';--处理企典的计费标志
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_ADD_QIDIAN_2015('''||V_BEGIN||''','''||V_END||'''); END;';--将2.5和3.0平台合并，生成日报.因为月报生成比较慢，可能会影响日报发送，所以调到月报前面
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_NEW('''||V_BEGIN||''','''||V_END||'''); END;';--只统计3.0平台的数据
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_OLD_2015('''||V_BEGIN||''','''||V_END||'''); END;';--只统计2.5平台的数据
  EXECUTE IMMEDIATE 'BEGIN P_ETL_DAILY_RELATION_2015('''||V_BEGIN||''','''||V_END||'''); END;';--关联关系日报
  EXECUTE IMMEDIATE 'BEGIN P_ETL_MONTH_ADD_QIDIAN_2015('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--将2.5和3.0平台合并，生成月报数据
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_MONTH_ADD_QIDIAN_CUS_ZZ('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--中证征信 9月份特殊处理
  
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_CONTRACT('''||IS_RUN_MONTH||''','''||V_CONTRACT||'''); END;';--处理账单的账期，每月1号处理当月数据，是否执行在存储过程内控制
  EXECUTE IMMEDIATE 'BEGIN P_ETL_LEIJI_ADD_QIDIAN_2015('''||IS_RUN_MONTH||''','''||V_MONTH||'''); END;';--将2.5和3.0平台合并，生成累计数据
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_CUSTNAME('''||V_BEGIN||'''); END;'; --参数只是在写日志时记录是何时更新的
  --EXECUTE IMMEDIATE 'BEGIN DM_REGCAP_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按注册资本统计
  --EXECUTE IMMEDIATE 'BEGIN DM_PROVINCE_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按省份统计
  --EXECUTE IMMEDIATE 'BEGIN DM_INDUSTRY_DAILY_PRO('''||V_BEGIN||''','''||V_END||'''); END;';--生成统计表，按行业统计  
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_ALI_DAILY('''||V_BEGIN||''','''||V_END||'''); END;';--生成阿里日报统计，区分企业查询结果的法人是否为空
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_BI_DAILY_NEW('''||V_BEGIN||''','''||V_END||'''); END;';--生成运营分析的日报数据
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_RESPONSE_DAILY('''||V_BEGIN||''','''||V_END||'''); END;';--响应时间汇总表
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_ORDER_COUNT('''||V_BEGIN||''','''||V_END||'''); END;';--2.5平台订单统计
  --EXECUTE IMMEDIATE 'BEGIN P_ETL_IS_LEGAL('''||V_BEGIN||''','''||V_END||'''); END;';--2.5平台订单,企业基本信息查询，按注册号和统一社会信用代码查询时，查询关键字是否合法.0为合法，1为不合法
  
END P_ETL_CALL_2015;
/

