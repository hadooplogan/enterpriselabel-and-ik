CREATE PROCEDURE P_LYJ_DEL AS 
BEGIN
   delete from DW_ORDER_3 where STARTTIME>=to_date('2017-06-08','YYYY-MM-DD');
   commit;
END P_LYJ_DEL;
/

