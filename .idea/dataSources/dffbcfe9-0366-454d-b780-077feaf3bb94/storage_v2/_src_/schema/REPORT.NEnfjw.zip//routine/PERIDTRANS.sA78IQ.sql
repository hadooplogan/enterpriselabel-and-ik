CREATE function peridtrans(cerno varchar2)
return varchar2 as
language java name 'TransPerid.trans(java.lang.String) return java.lang.String';
/

