CREATE PROCEDURE dm_industry_daily_pro (V_BEGIN VARCHAR2,V_END VARCHAR2) AS
V_DATE VARCHAR2(8);
-------------------------------------------------------------
--NAME:    dm_industry_daily_pro
--PURPOSE: 生成行业分布汇总表
--CREATOR： 陈志斌
--DATE:    2016-11-29
-------------------------------------------------------------
begin
  PRO_LOG('dm_industry_daily_pro','抽取'||V_BEGIN||'到'||V_END||'行业分布汇总数据开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP   
    BEGIN
--删除当天原有数据
  DELETE FROM DM_INDUSTRY_DAILY WHERE   ORDER_DATE=V_DATE;
insert into dm_industry_daily
 select industrycocode,
       b.codename,
       INDUSTRYPHYCODE,
       a.id_customer,
       order_date,
       hy1,
       hy2,
       c.full_name
  from (select distinct industrycocode,
                        industryphycode,
                        id_customer,
                        order_date,
                        count(*) over(partition by industryphycode, id_customer, order_date) as hy1,
                        count(*) over(partition by industrycocode, id_customer, order_date) as hy2
          from dw_order_detail
         where 
            order_date = v_date) a,
       T_DEX_APP_CODELIST B,
       (SELECT DISTINCT ID_CUSTOMER, FULL_NAME FROM DIM_CUSTOMER) C
 where a.id_customer = c.id_customer
   and b.codevalue = a.industrycocode
   and code_type_value in ('CA06');

commit;
  PRO_LOG('dm_industry_daily_pro','抽取'||V_DATE||'行业分布汇总数据结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');
end;
  END LOOP; 
  COMMIT;
  PRO_LOG('dm_industry_daily_pro','抽取'||V_BEGIN||'到'||V_END||'行业分布汇总数据结束');

end  ;
/

