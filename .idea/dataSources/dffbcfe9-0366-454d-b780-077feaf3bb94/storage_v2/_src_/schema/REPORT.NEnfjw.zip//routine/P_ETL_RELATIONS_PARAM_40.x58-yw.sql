CREATE PROCEDURE P_ETL_RELATIONS_PARAM_40 (V_BEGIN VARCHAR2,V_END VARCHAR2)  AS
V_DATE VARCHAR2(10);
V_CN NUMBER;               --查询对象个数
I NUMBER;
TEMP_PARAM VARCHAR2(2000); 
V_PARAM VARCHAR2(2000);    --查询对象
-------------------------------------------
--NAME: P_ETL_RELATIONS_PARAM_40
--PURPOSE:处理多节点关联关系参数的顺序问题,关联关系默认去重 4.0平台
--CREATOR： 夏培娟
--DATE:    2018-01-05
-------------------------------------------
 begin 
  PRO_LOG('P_RELATIONS_PARAM','处理'||V_BEGIN||'到'||V_END||'关联洞察查询参数开始');
  V_DATE:=V_BEGIN;
  WHILE V_DATE<=V_END LOOP

  --定义游标，一次处理一天
  --------------------处理多节点关联关系 relations下的多节点------------------------
  DECLARE
  CURSOR C_RELATIONS1 IS
  select order_no
  FROM DW_ORDER_QIDIAN
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('muti_nodes')
    and customerid<>'2c918092576f9066015774c7be6e00b0' --中数应用监控客户
    and ORDER_DATE = V_DATE;
  C_ROWS1  C_RELATIONS1%ROWTYPE;
  --打开游标，每次循环处理一行
  BEGIN
  OPEN C_RELATIONS1;
    LOOP
      FETCH C_RELATIONS1 INTO C_ROWs1;
      --处理为行
      DELETE FROM DW_RELATIONS_TEMP;
      COMMIT;
      --一行变为多行，同时根据参数排序赋值
      INSERT INTO DW_RELATIONS_TEMP
        (C_SORT, ORDER_NO, PARAM, PARAM_ONE)
      SELECT ROWNUM C_SORT,ORDER_NO,PARAM,PARAM_ONE
      FROM
        (SELECT ORDER_NO,
          PARAM,
          REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL) PARAM_ONE
         FROM
           (SELECT ORDER_NO,
              PARAM,
              replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"mks":')+8),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"mks":')+8),']')-2),'"','') PARAM_BRIEF
            FROM DW_ORDER_QIDIAN
            WHERE  ORDER_NO     =C_ROWs1.ORDER_NO
              AND  ORDER_DATE = V_DATE
           )
        CONNECT BY LEVEL<LENGTH(PARAM_BRIEF)-LENGTH(REPLACE(PARAM_BRIEF,',',''))+2
        ORDER BY REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL)
        );
        COMMIT;
      --将多行变为一行
      SELECT COUNT(*) INTO V_CN
      FROM DW_RELATIONS_TEMP;
      
      V_PARAM:='';
      --开始循环处理查询参数
      FOR I IN 1..V_CN LOOP
        BEGIN
        SELECT PARAM_ONE INTO TEMP_PARAM
        FROM DW_RELATIONS_TEMP
        WHERE C_SORT=I;
        END;
        
        V_PARAM:=V_PARAM||','||TEMP_PARAM;
      END LOOP;
      
      UPDATE DW_ORDER_QIDIAN
      SET PARAM_CN=V_CN,PARAM_AFTER=SUBSTR(V_PARAM,2),--因为初始赋值为空，所以多一个逗号
        PARAM_LAYER=case when replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),',')-1),'"','')='null' then null else replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),',')-1),'"','') end,--提取出层级
        FUNCTIONCODE_AFTER='muti_nodes'
      WHERE ORDER_NO=C_ROWS1.ORDER_NO
        AND  ORDER_DATE=V_DATE;
      COMMIT;
      
      EXIT WHEN C_RELATIONS1%NOTFOUND;
    END LOOP;
  CLOSE C_RELATIONS1;
  END;
  
  --定义游标，一次处理一天
  --------------------处理多节点关联关系 relations下的多节点异步------------------------
  DECLARE
  CURSOR C_RELATIONS2 IS
  select order_no
  FROM DW_ORDER_qidian
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations')
    AND FUNCTIONCODE IN ('asyn_muti_nodes')
    and ORDER_DATE = V_DATE;
  C_ROWS2  C_RELATIONS2%ROWTYPE;
  --打开游标，每次循环处理一行
  BEGIN
  OPEN C_RELATIONS2;
    LOOP
      FETCH C_RELATIONS2 INTO C_ROWs2;
      --处理为行
      DELETE FROM DW_RELATIONS_TEMP;
      COMMIT;
      --一行变为多行，同时根据参数排序赋值
      INSERT INTO DW_RELATIONS_TEMP
        (C_SORT, ORDER_NO, PARAM, PARAM_ONE)
      SELECT ROWNUM C_SORT,ORDER_NO,PARAM,PARAM_ONE
      FROM
        (SELECT ORDER_NO,
          PARAM,
          REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL) PARAM_ONE
         FROM
           (SELECT ORDER_NO,
              PARAM,
              replace(replace(substr(substr(param,instr(param,'"mks":')+7),1,instr(substr(param,instr(param,'"mks":')+7),',')-1),'"',''),'|',',') PARAM_BRIEF
            FROM DW_ORDER_QIDIAN
            WHERE ORDER_NO     =C_ROWs2.ORDER_NO
              AND ORDER_DATE = V_DATE
           )
        CONNECT BY LEVEL<LENGTH(PARAM_BRIEF)-LENGTH(REPLACE(PARAM_BRIEF,',',''))+2
        ORDER BY REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL)
        );
        COMMIT;
      --将多行变为一行
      SELECT COUNT(*) INTO V_CN
      FROM DW_RELATIONS_TEMP;
      
      V_PARAM:='';
      --开始循环处理查询参数
      FOR I IN 1..V_CN LOOP
        BEGIN
        SELECT PARAM_ONE INTO TEMP_PARAM
        FROM DW_RELATIONS_TEMP
        WHERE C_SORT=I;
        END;
        
        V_PARAM:=V_PARAM||','||TEMP_PARAM;
      END LOOP;
      
      UPDATE DW_ORDER_QIDIAN
      SET PARAM_CN=V_CN,PARAM_AFTER=SUBSTR(V_PARAM,2),--因为初始赋值为空，所以多一个逗号
        PARAM_LAYER=replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),',')-1),'"',''),--提取出层级
        FUNCTIONCODE_AFTER='muti_nodes'
      WHERE ORDER_NO=C_ROWs2.ORDER_NO
        AND ORDER_DATE=V_DATE;
      COMMIT;
      
      EXIT WHEN C_RELATIONS2%NOTFOUND;
    END LOOP;
  CLOSE C_RELATIONS2;
  END;
  
    --------------------处理多节点关联关系 relation下的 前海征信 4.0目前没有查询，不知道参数具体是什么样的------------------------
  DECLARE
  CURSOR C_RELATION3 IS
  select order_no
  FROM DW_ORDER_qidian
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relation')
    AND FUNCTIONCODE IN ('multipleNodeRelation')
    and ORDER_DATE = V_DATE;
  C_ROW3   C_RELATION3%ROWTYPE;
  
  --打开游标，每次循环处理一行
  BEGIN
  OPEN C_RELATION3;
    LOOP
      FETCH C_RELATION3 INTO C_ROW3;
      --处理为行
      DELETE FROM DW_RELATIONS_TEMP;
      COMMIT;
      --一行变为多行，同时根据参数排序赋值
      INSERT INTO DW_RELATIONS_TEMP
        (C_SORT, ORDER_NO, PARAM, PARAM_ONE)
      SELECT ROWNUM C_SORT,ORDER_NO,PARAM,PARAM_ONE
      FROM
        (SELECT ORDER_NO,
          PARAM,
          REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL) PARAM_ONE
         FROM
           (SELECT ORDER_NO,
              PARAM,
              REPLACE(SUBSTR(PARAM,INSTR(PARAM,'"key":"')+7,LENGTH(PARAM)-INSTR(PARAM,'"key":')-8),'|',',') PARAM_BRIEF
            FROM DW_ORDER_QIDIAN
            WHERE ORDER_NO     =C_ROW3.ORDER_NO
              AND ORDER_DATE = V_DATE
           )
        CONNECT BY LEVEL<LENGTH(PARAM_BRIEF)-LENGTH(REPLACE(PARAM_BRIEF,',',''))+2
        ORDER BY REGEXP_SUBSTR(PARAM_BRIEF,'[^,]+',1,LEVEL)
        );
        COMMIT;
      --将多行变为一行
      SELECT COUNT(*) INTO V_CN
      FROM DW_RELATIONS_TEMP;
      
      V_PARAM:='';
      --开始循环处理查询参数
      FOR I IN 1..V_CN LOOP
        BEGIN
        SELECT PARAM_ONE INTO TEMP_PARAM
        FROM DW_RELATIONS_TEMP
        WHERE C_SORT=I;
        END;
        
        V_PARAM:=V_PARAM||','||TEMP_PARAM;
      END LOOP;
      
      UPDATE DW_ORDER_QIDIAN
      SET PARAM_CN=V_CN,PARAM_AFTER=SUBSTR(V_PARAM,2),--因为初始赋值为空，所以多一个逗号
        PARAM_LAYER=replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"graphStep":"')+12),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"graphStep":"')+12),',')-1),'"',''),--提取出层级
        FUNCTIONCODE_AFTER='multipleNodeRelation'
      WHERE ORDER_NO=C_ROW3.ORDER_NO
        AND ORDER_DATE=V_DATE;
      COMMIT;
      
      EXIT WHEN C_RELATION3%NOTFOUND;
    END LOOP;
  CLOSE C_RELATION3;
  END;

   -------------处理控制路径、实质关联、族谱的查询参数-----------------
  BEGIN
  ---------------控制路径-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=SUBSTR(PARAM,13,INSTR(PARAM,'"relations":')-15),--只有企业名称，不涉及层级
    FUNCTIONCODE_AFTER='control_path'
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations','relation')
    AND FUNCTIONCODE IN ('control_path','asyn_control_path')
    and ORDER_DATE = V_DATE;
  COMMIT;
  
  ---------------实质关联-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=SUBSTR(PARAM,13,length(param)-14),--只有企业名称，不涉及层级
    FUNCTIONCODE_AFTER='real_relation'
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations','relation')
    AND FUNCTIONCODE IN ('real_relation')
    and ORDER_DATE = V_DATE;
  COMMIT;
  
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER=substr(SUBSTR(PARAM,instr(param,'"entmark":')+11),1,instr(SUBSTR(PARAM,instr(param,'"entmark":')+11),'"')-1),--只有企业名称，不涉及层级
    FUNCTIONCODE_AFTER='real_relation'
  WHERE STATE='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations','relation')
    AND FUNCTIONCODE IN ('asyn_real_relation')
    and ORDER_DATE = V_DATE;
  COMMIT;
  
   ---------------族谱-----------------
  UPDATE DW_ORDER_QIDIAN
  SET PARAM_AFTER= SUBSTR(SUBSTR(PARAM,INSTR(PARAM,'"entmark":')+11),1,INSTR(SUBSTR(PARAM,INSTR(PARAM,'"entmark":')+11),'"')-1),
    PARAM_LAYER=(case when INSTR(PARAM,'"layer":')=0 then null else replace(substr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),1,instr(SUBSTR(PARAM,INSTR(PARAM,'"layer":')+8),',')-1),'"','') end),
    FUNCTIONCODE_AFTER='genealogy'
  WHERE state='200' --只处理成功的订单 规避掉因为参数不合规造成的此更新语句执行失败
    and ES_FROM='4.0'
    AND PRODUCTCODE  IN ('relations','relation')
    AND FUNCTIONCODE IN ('genealogy','asyn_genealogy')
    and ORDER_DATE = V_DATE;
  COMMIT;
  
  END;
  
  PRO_LOG('P_RELATIONS_PARAM','处理'||V_DATE||'关联洞察查询参数结束');
  V_DATE:=TO_CHAR(TO_DATE(V_DATE,'yyyy-mm-dd')+1,'yyyymmdd');

  END LOOP;
  
END P_ETL_RELATIONS_PARAM_40;
/

